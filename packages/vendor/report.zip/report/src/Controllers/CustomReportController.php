<?php

namespace Vendor\Report\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Employee;
use App\Models\Client;
use App\Models\Device;
use App\Models\EmployeeSchedule;
use App\Models\Leave;
use App\Models\EmployeePermission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Barryvdh\DomPDF\Facade\Pdf;

class CustomReportController extends Controller
{
    /**
     * Afficher la page du rapport personnalisé
     */
    public function presencePonctualite(Request $request)
    {
        $client = Client::where('user_id', auth()->user()->id)->first();
        
        if (!$client) {
            return redirect()->route('home')->with('error', 'Client non trouvé.');
        }
        
        // Récupérer les employés pour les filtres
        $employees = Employee::where('client_id', $client->id)
            ->whereNotNull('emp_code')
            ->where('emp_code', '!=', '')
            ->orderBy('emp_code')
            ->get()
            ->map(function($employee) {
                return [
                    'emp_code' => $employee->emp_code,
                    'full_name' => $employee->first_name . ($employee->last_name ? ' ' . $employee->last_name : '')
                ];
            });
        
        return view('report::ponctualites.index', compact('employees', 'client'));
    }
    
    /**
     * Générer les données pour le rapport personnalisé
     */
    public function generateCustomReport(Request $request)
    {
        try {
            $client = Client::where('user_id', auth()->user()->id)->first();
            
            if (!$client) {
                return response()->json(['error' => 'Client non trouvé'], 404);
            }
            
            // Valider les paramètres
            $validator = \Validator::make($request->all(), [
                'start_date' => 'required|date',
                'end_date' => 'required|date|after_or_equal:start_date',
                'emp_code' => 'nullable|string'
            ]);
            
            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()->first()], 400);
            }
            
            $startDate = $request->input('start_date');
            $endDate = $request->input('end_date');
            $empCode = $request->input('emp_code', 'all');
            
            // Récupérer les données du rapport
            $reportData = $this->getPresencePonctualiteData($client, $startDate, $endDate, $empCode);
            
            return response()->json([
                'success' => true,
                'data' => $reportData,
                'total_employees' => count($reportData),
                'period' => [
                    'start_date' => $startDate,
                    'end_date' => $endDate
                ]
            ]);
            
        } catch (\Exception $e) {
            Log::error('Erreur génération rapport personnalisé: ' . $e->getMessage());
            return response()->json(['error' => 'Erreur serveur: ' . $e->getMessage()], 500);
        }
    }
    
    /**
     * Exporter le rapport personnalisé en PDF
     */
    public function exportCustomPdf(Request $request)
    {
        try {
            $client = Client::where('user_id', auth()->user()->id)->first();
            
            if (!$client) {
                return redirect()->back()->with('error', 'Client non trouvé.');
            }
            
            // Valider les paramètres
            $validator = \Validator::make($request->all(), [
                'start_date' => 'required|date',
                'end_date' => 'required|date|after_or_equal:start_date',
                'emp_code' => 'nullable|string'
            ]);
            
            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            
            $startDate = $request->input('start_date');
            $endDate = $request->input('end_date');
            $empCode = $request->input('emp_code', 'all');
            
            // Récupérer les données du rapport
            $reportData = $this->getPresencePonctualiteData($client, $startDate, $endDate, $empCode);
            
            // Calculer les totaux
            $totals = $this->calculateTotals($reportData);
            
            // Préparer les données pour la vue PDF
            $data = [
                'start_date' => $startDate,
                'end_date' => $endDate,
                'export_date' => Carbon::now(),
                'client' => $client,
                'filters' => [
                    'emp_code' => $empCode === 'all' ? 'Tous les employés' : $empCode
                ],
                'report_data' => $reportData,
                'totals' => $totals,
                'total_employees' => count($reportData),
                'period_days' => Carbon::parse($startDate)->diffInDays(Carbon::parse($endDate)) + 1
            ];
            
            // Générer le PDF avec la vue personnalisée
            $pdf = Pdf::loadView('report::pontualites.exports.pdf', $data);
            
            // Nom du fichier
            $filename = 'rapport_presence_ponctualite_' . Carbon::now()->format('Y-m-d_H-i-s') . '.pdf';
            
            // Options du PDF
            $pdf->setPaper('A4', 'landscape');
            
            return $pdf->download($filename);
            
        } catch (\Exception $e) {
            Log::error('Erreur export PDF personnalisé: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Erreur lors de la génération du PDF: ' . $e->getMessage());
        }
    }

    /**
 * Exporter le rapport par département en PDF
 */
public function exportDepartmentPdf(Request $request)
{
    try {
        $client = Client::where('user_id', auth()->user()->id)->first();
        
        if (!$client) {
            return redirect()->back()->with('error', 'Client non trouvé.');
        }
        
        // Valider les paramètres
        $validator = \Validator::make($request->all(), [
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'department_id' => 'nullable|integer'
        ]);
        
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        
        $startDate = $request->input('start_date');
        $endDate = $request->input('end_date');
        $departmentId = $request->input('department_id', 'all');
        
        // Récupérer les données par département
        $departmentData = $this->getDepartmentData($client, $startDate, $endDate, $departmentId);
        
        // Calculer les totaux
        $totals = $this->calculateDepartmentTotals($departmentData);
        
        // Préparer les données pour la vue PDF
        $data = [
            'start_date' => $startDate,
            'end_date' => $endDate,
            'export_date' => Carbon::now(),
            'client' => $client,
            'filters' => [
                'department_id' => $departmentId === 'all' ? 'Tous les départements' : $departmentId
            ],
            'department_data' => $departmentData,
            'totals' => $totals,
            'total_departments' => count($departmentData),
            'period_days' => Carbon::parse($startDate)->diffInDays(Carbon::parse($endDate)) + 1
        ];
        
        // Générer le PDF avec la vue personnalisée
        $pdf = Pdf::loadView('report::pontualites.departements.exports.pdf', $data);
        
        // Nom du fichier
        $filename = 'rapport_departements_' . Carbon::now()->format('Y-m-d_H-i-s') . '.pdf';
        
        // Options du PDF
        $pdf->setPaper('A4', 'landscape');
        
        return $pdf->download($filename);
        
    } catch (\Exception $e) {
        Log::error('Erreur export PDF département: ' . $e->getMessage());
        return redirect()->back()->with('error', 'Erreur lors de la génération du PDF: ' . $e->getMessage());
    }
}

/**
 * Récupérer les données par département
 */
private function getDepartmentData($client, $startDate, $endDate, $departmentId)
{
    // Initialiser les données
    $departmentData = [];
    
    // Récupérer les départements
    $departmentsQuery = Department::where('client_id', $client->id);
    
    if ($departmentId !== 'all') {
        $departmentsQuery->where('id', $departmentId);
    }
    
    $departments = $departmentsQuery->get();
    
    foreach ($departments as $department) {
        // Récupérer les employés du département
        $employees = Employee::where('client_id', $client->id)
            ->where('department_id', $department->id)
            ->get();
        
        $totalEmployees = $employees->count();
        $totalPresence = 0;
        $totalAbsence = 0;
        $totalOnTime = 0;
        $totalLate = 0;
        
        // Calculer les statistiques pour chaque employé
        foreach ($employees as $employee) {
            // Récupérer les données de présence pour l'employé
            $employeeData = $this->getEmployeePresenceData($employee, $startDate, $endDate);
            
            $totalPresence += $employeeData['presence_data']['present'] ?? 0;
            $totalAbsence += $employeeData['presence_data']['absent'] ?? 0;
            $totalOnTime += $employeeData['ponctualite_data']['on_time'] ?? 0;
            $totalLate += $employeeData['ponctualite_data']['late'] ?? 0;
        }
        
        // Calculer les taux
        $totalDays = ($totalPresence + $totalAbsence) > 0 ? ($totalPresence + $totalAbsence) : 1;
        $presenceRate = $totalDays > 0 ? round(($totalPresence / $totalDays) * 100, 2) : 0;
        
        $totalChecks = ($totalOnTime + $totalLate) > 0 ? ($totalOnTime + $totalLate) : 1;
        $ponctualiteRate = $totalChecks > 0 ? round(($totalOnTime / $totalChecks) * 100, 2) : 0;
        
        // Stocker les données du département
        $departmentData[] = [
            'department_id' => $department->id,
            'department_name' => $department->name,
            'employee_count' => $totalEmployees,
            'presence_data' => [
                'present' => $totalPresence,
                'absent' => $totalAbsence,
                'rate' => $presenceRate
            ],
            'ponctualite_data' => [
                'on_time' => $totalOnTime,
                'late' => $totalLate,
                'rate' => $ponctualiteRate
            ],
            'total_rate' => $presenceRate + $ponctualiteRate
        ];
    }
    
    // Trier par taux total décroissant
    usort($departmentData, function($a, $b) {
        return $b['total_rate'] <=> $a['total_rate'];
    });
    
    return $departmentData;
}

/**
 * Calculer les totaux par département
 */
private function calculateDepartmentTotals($departmentData)
{
    $totals = [
        'total_departments' => count($departmentData),
        'total_employees' => 0,
        'total_presence_present' => 0,
        'total_presence_absent' => 0,
        'total_ponctualite_on_time' => 0,
        'total_ponctualite_late' => 0,
        'avg_presence_rate' => 0,
        'avg_ponctualite_rate' => 0
    ];
    
    $totalPresenceRate = 0;
    $totalPonctualiteRate = 0;
    
    foreach ($departmentData as $department) {
        $totals['total_employees'] += $department['employee_count'];
        $totals['total_presence_present'] += $department['presence_data']['present'];
        $totals['total_presence_absent'] += $department['presence_data']['absent'];
        $totals['total_ponctualite_on_time'] += $department['ponctualite_data']['on_time'];
        $totals['total_ponctualite_late'] += $department['ponctualite_data']['late'];
        
        $totalPresenceRate += $department['presence_data']['rate'];
        $totalPonctualiteRate += $department['ponctualite_data']['rate'];
    }
    
    // Calculer les moyennes
    if (count($departmentData) > 0) {
        $totals['avg_presence_rate'] = round($totalPresenceRate / count($departmentData), 2);
        $totals['avg_ponctualite_rate'] = round($totalPonctualiteRate / count($departmentData), 2);
    }
    
    return $totals;
}
    
    /**
     * Récupérer les données de présence et ponctualité
     */
    private function getPresencePonctualiteData($client, $startDate, $endDate, $empCode)
    {
        // Récupérer les employés selon le filtre
        $employeesQuery = Employee::where('client_id', $client->id)
            ->whereNotNull('emp_code')
            ->where('emp_code', '!=', '');
        
        if ($empCode && $empCode !== 'all') {
            $employeesQuery->where('emp_code', $empCode);
        }
        
        $employees = $employeesQuery->orderBy('emp_code')->get();
        
        if ($employees->isEmpty()) {
            return [];
        }
        
        // Récupérer le token d'authentification
        $accessConfig = DB::table('access_configs')->where('client_id', $client->id)->first();
        $token = $accessConfig->general_token ?? null;
        
        if (!$token) {
            return [];
        }
        
        // Récupérer tous les devices
        $devices = Device::where('client_id', $client->id)->get();
        
        if ($devices->isEmpty()) {
            return [];
        }
        
        // Récupérer les permissions approuvées
        $permissions = EmployeePermission::where('client_id', $client->id)
            ->where('status', 'approved')
            ->whereBetween('date', [$startDate, $endDate])
            ->get()
            ->groupBy('employee_id');
        
        // Récupérer les congés
        $leaves = Leave::where('client_id', $client->id)
            ->whereBetween('start_date', [$startDate, $endDate])
            ->get();
        
        $reportData = [];
        $orderNumber = 1;
        
        foreach ($employees as $employee) {
            // Analyser chaque jour de la période
            $analysis = $this->analyzeEmployeePeriod(
                $employee,
                $startDate,
                $endDate,
                $devices,
                $token,
                $permissions,
                $leaves
            );
            
            if ($analysis) {
                $reportData[] = [
                    'order_number' => $orderNumber++,
                    'employee_code' => $employee->emp_code,
                    'employee_name' => $employee->first_name . ($employee->last_name ? ' ' . $employee->last_name : ''),
                    'presence_data' => $analysis['presence'],
                    'ponctualite_data' => $analysis['ponctualite'],
                    'total_days' => $analysis['total_days'],
                    'observation' => $analysis['observation']
                ];
            }
        }
        
        return $reportData;
    }
    
    /**
     * Analyser la période pour un employé
     */
    private function analyzeEmployeePeriod($employee, $startDate, $endDate, $devices, $token, $permissions, $leaves)
    {
        $currentDate = Carbon::parse($startDate);
        $endDateObj = Carbon::parse($endDate);
        
        $presenceData = [
            'present_count' => 0,
            'absent_count' => 0,
            'present_days' => [], // Pour stocker les jours spécifiques (ex: "20/20")
            'absent_days' => []  // Pour stocker les absences spécifiques
        ];
        
        $ponctualiteData = [
            'on_time_count' => 0,
            'late_count' => 0,
            'late_minutes_total' => 0,
            'on_time_days' => [], // Pour stocker les jours à l'heure
            'late_days' => []     // Pour stocker les jours en retard
        ];
        
        $totalWorkingDays = 0;
        $observations = [];
        
        while ($currentDate <= $endDateObj) {
            $dateStr = $currentDate->format('Y-m-d');
            $dayOfWeek = $currentDate->dayOfWeekIso;
            
            // Vérifier si c'est un jour de travail (lundi-vendredi)
            $isWorkingDay = ($dayOfWeek >= 1 && $dayOfWeek <= 5);
            
            if ($isWorkingDay) {
                $totalWorkingDays++;
                
                // Récupérer le planning de l'employé
                $schedule = $this->getEmployeeScheduleForDate($employee, $dateStr);
                
                // Récupérer les transactions pour ce jour
                $transactions = $this->getEmployeeTransactionsForDate($employee, $currentDate, $devices, $token);
                
                // Vérifier les permissions
                $hasPermission = $this->hasPermission($employee->id, $dateStr, $permissions);
                
                // Vérifier les congés
                $isOnLeave = $this->isEmployeeOnLeave($employee->id, $dateStr, $leaves);
                
                // Analyser la présence
                $arrivalTime = $transactions['arrival_time'] ?? null;
                $departureTime = $transactions['departure_time'] ?? null;
                
                $isPresent = ($arrivalTime !== null || $departureTime !== null);
                
                if ($isOnLeave) {
                    // Congé
                    $observations[] = 'Congé le ' . $currentDate->format('d/m');
                } else if ($hasPermission) {
                    // Permission
                    $observations[] = 'Permission le ' . $currentDate->format('d/m');
                } else if ($isPresent) {
                    $presenceData['present_count']++;
                    $presenceData['present_days'][] = $currentDate->format('d/m');
                    
                    // Analyser la ponctualité si c'est un jour avec planning
                    if ($schedule && $schedule->start_time && $arrivalTime !== null) {
                        $scheduleStart = Carbon::createFromFormat('H:i:s', $schedule->start_time->format('H:i:s'));
                        $actualArrival = Carbon::createFromFormat('H:i:s', $arrivalTime);
                        
                        if ($actualArrival > $scheduleStart) {
                            $lateMinutes = $actualArrival->diffInMinutes($scheduleStart);
                            
                            // Tolérance de 5 minutes
                            if ($lateMinutes > 5) {
                                $ponctualiteData['late_count']++;
                                $ponctualiteData['late_minutes_total'] += $lateMinutes;
                                $ponctualiteData['late_days'][] = $currentDate->format('d/m') . ' (' . $lateMinutes . ' min)';
                                $observations[] = 'Retard de ' . $lateMinutes . ' min le ' . $currentDate->format('d/m');
                            } else {
                                $ponctualiteData['on_time_count']++;
                                $ponctualiteData['on_time_days'][] = $currentDate->format('d/m');
                            }
                        } else {
                            $ponctualiteData['on_time_count']++;
                            $ponctualiteData['on_time_days'][] = $currentDate->format('d/m');
                        }
                    } else if ($isPresent) {
                        // Présent mais pas de planning ou pas d'arrivée enregistrée
                        $ponctualiteData['on_time_count']++;
                        $ponctualiteData['on_time_days'][] = $currentDate->format('d/m');
                    }
                } else {
                    // Absent sans justification
                    $presenceData['absent_count']++;
                    $presenceData['absent_days'][] = $currentDate->format('d/m');
                    $observations[] = 'Absent le ' . $currentDate->format('d/m');
                }
            }
            
            $currentDate->addDay();
        }
        
        // Calculer les taux
        $presenceRate = $totalWorkingDays > 0 ? round(($presenceData['present_count'] / $totalWorkingDays) * 100, 1) : 0;
        $ponctualiteRate = $presenceData['present_count'] > 0 ? round(($ponctualiteData['on_time_count'] / $presenceData['present_count']) * 100, 1) : 0;
        
        return [
            'presence' => [
                'present' => $presenceData['present_count'],
                'absent' => $presenceData['absent_count'],
                'rate' => $presenceRate,
                'present_days_display' => $presenceData['present_count'] . '/' . $totalWorkingDays,
                'absent_days_display' => $presenceData['absent_count'] . '/' . $totalWorkingDays
            ],
            'ponctualite' => [
                'on_time' => $ponctualiteData['on_time_count'],
                'late' => $ponctualiteData['late_count'],
                'rate' => $ponctualiteRate,
                'avg_late_minutes' => $ponctualiteData['late_count'] > 0 ? 
                    round($ponctualiteData['late_minutes_total'] / $ponctualiteData['late_count'], 1) : 0
            ],
            'total_days' => $totalWorkingDays,
            'observation' => implode(', ', array_slice($observations, 0, 3)) . 
                (count($observations) > 3 ? '... (+' . (count($observations) - 3) . ' autres)' : '')
        ];
    }
    
    /**
     * Récupérer les transactions d'un employé pour une date
     */
    private function getEmployeeTransactionsForDate($employee, $date, $devices, $token)
    {
        $startTime = $date->copy()->startOfDay()->format('Y-m-d H:i:s');
        $endTime = $date->copy()->endOfDay()->format('Y-m-d H:i:s');
        
        $allTransactions = collect();
        
        foreach ($devices as $device) {
            try {
                $response = Http::withHeaders([
                    'Authorization' => 'Token ' . $token,
                    'Accept' => 'application/json',
                ])->withOptions([
                    'verify' => false,
                    'timeout' => 30,
                ])->get('http://54.37.15.111/iclock/api/transactions/', [
                    'page' => 1,
                    'limit' => 50,
                    'terminal_sn' => $device->device_sn,
                    'emp_code' => $employee->emp_code,
                    'start_time' => $startTime,
                    'end_time' => $endTime
                ]);
                
                if ($response->successful()) {
                    $data = $response->json();
                    if (isset($data['data']) && is_array($data['data'])) {
                        $allTransactions = $allTransactions->merge($data['data']);
                    }
                }
                
            } catch (\Exception $e) {
                Log::error("Erreur récupération transactions: " . $e->getMessage());
            }
        }
        
        // Grouper par employé
        return $this->groupTransactionsByEmployee($allTransactions, collect([$employee]));
    }
    
    /**
     * Grouper les transactions par employé (méthode similaire à ReportController)
     */
    private function groupTransactionsByEmployee($transactions, $employees)
    {
        $grouped = [];
        
        foreach ($transactions as $transaction) {
            $empCode = $transaction['emp_code'] ?? null;
            if (!$empCode) continue;
            
            $punchTime = Carbon::parse($transaction['punch_time']);
            $timeStr = $punchTime->format('H:i:s');
            
            if (!isset($grouped[$empCode])) {
                $grouped[$empCode] = [
                    'arrival_time' => null,
                    'departure_time' => null,
                    'all_punches' => []
                ];
            }
            
            $grouped[$empCode]['all_punches'][] = $timeStr;
            
            // Déterminer si c'est une arrivée ou un départ
            $hour = $punchTime->hour;
            $isArrival = ($hour < 14);
            
            // Garder la première arrivée et le dernier départ
            if ($isArrival) {
                if (!$grouped[$empCode]['arrival_time'] || $timeStr < $grouped[$empCode]['arrival_time']) {
                    $grouped[$empCode]['arrival_time'] = $timeStr;
                }
            } else {
                if (!$grouped[$empCode]['departure_time'] || $timeStr > $grouped[$empCode]['departure_time']) {
                    $grouped[$empCode]['departure_time'] = $timeStr;
                }
            }
        }
        
        return $grouped[$employees->first()->emp_code] ?? null;
    }
    
    /**
     * Récupérer le planning d'un employé pour une date (similaire à ReportController)
     */
    private function getEmployeeScheduleForDate($employee, $dateStr)
    {
        $date = Carbon::parse($dateStr);
        $dayOfWeek = $date->dayOfWeekIso;
        $dayName = $date->locale('fr')->dayName;
        
        // Chercher d'abord les plannings spécifiques à la date
        $specificSchedule = EmployeeSchedule::where('client_id', $employee->client_id)
            ->where('employee_id', $employee->id)
            ->where('specific_date', $dateStr)
            ->first();
        
        if ($specificSchedule) {
            return $specificSchedule;
        }
        
        // Chercher les plannings fixes par jour de semaine
        $fixedSchedule = EmployeeSchedule::where('client_id', $employee->client_id)
            ->where('employee_id', $employee->id)
            ->where('schedule_type', 'fixe')
            ->where('day_of_week', $dayOfWeek)
            ->where('repeat_weekly', true)
            ->where(function($query) use ($dateStr) {
                $query->whereNull('start_date')
                      ->orWhere('start_date', '<=', $dateStr);
            })
            ->where(function($query) use ($dateStr) {
                $query->whereNull('end_date')
                      ->orWhere('end_date', '>=', $dateStr);
            })
            ->first();
        
        if ($fixedSchedule) {
            return $fixedSchedule;
        }
        
        // Chercher un planning par défaut
        return EmployeeSchedule::where('client_id', $employee->client_id)
            ->where('employee_id', $employee->id)
            ->where('schedule_type', 'fixe')
            ->where('day_of_week', $dayOfWeek)
            ->first();
    }
    
    /**
     * Vérifier si l'employé a une permission
     */
    private function hasPermission($employeeId, $date, $permissions)
    {
        if (isset($permissions[$employeeId])) {
            foreach ($permissions[$employeeId] as $permission) {
                if ($permission->date->format('Y-m-d') == $date) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Vérifier si l'employé est en congé
     */
    private function isEmployeeOnLeave($employeeId, $date, $leaves)
    {
        foreach ($leaves as $leave) {
            if ($leave->employee_id == $employeeId) {
                $leaveStart = Carbon::parse($leave->start_date);
                $leaveEnd = Carbon::parse($leave->end_date);
                $checkDate = Carbon::parse($date);
                
                if ($checkDate->between($leaveStart, $leaveEnd)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Calculer les totaux pour le rapport
     */
    private function calculateTotals($reportData)
    {
        $totals = [
            'total_employees' => count($reportData),
            'total_presence_present' => 0,
            'total_presence_absent' => 0,
            'total_ponctualite_on_time' => 0,
            'total_ponctualite_late' => 0,
            'avg_presence_rate' => 0,
            'avg_ponctualite_rate' => 0
        ];
        
        if (count($reportData) > 0) {
            foreach ($reportData as $data) {
                $totals['total_presence_present'] += $data['presence_data']['present'];
                $totals['total_presence_absent'] += $data['presence_data']['absent'];
                $totals['total_ponctualite_on_time'] += $data['ponctualite_data']['on_time'];
                $totals['total_ponctualite_late'] += $data['ponctualite_data']['late'];
            }
            
            $totals['avg_presence_rate'] = round(array_sum(array_column(array_column($reportData, 'presence_data'), 'rate')) / count($reportData), 1);
            $totals['avg_ponctualite_rate'] = round(array_sum(array_column(array_column($reportData, 'ponctualite_data'), 'rate')) / count($reportData), 1);
        }
        
        return $totals;
    }
}