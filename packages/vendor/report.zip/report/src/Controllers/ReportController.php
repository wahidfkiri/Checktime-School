<?php

namespace Vendor\Report\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Employee;
use App\Models\Client;
use App\Models\Device;
use App\Models\EmployeeSchedule;
use App\Models\Leave;
use App\Models\EmployeePermission;
use App\Models\DailyAttendance; // Ajout du modèle
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;
use Carbon\Carbon;
use Illuminate\Support\Collection;
use Barryvdh\DomPDF\Facade\Pdf;

class ReportController extends Controller
{
    /**
     * Afficher la page des rapports
     */
    public function absencesDelays(Request $request)
    {
        $client = Client::where('user_id', auth()->user()->id)->first();
        
        if (!$client) {
            return redirect()->route('home')->with('error', 'Client non trouvé.');
        }
        
        // Récupérer les employés pour les filtres
        $employees = Employee::where('client_id', $client->id)
            ->whereNotNull('emp_code')
            ->where('emp_code', '!=', '')
            ->orderBy('emp_code')
            ->get()
            ->map(function($employee) {
                return [
                    'emp_code' => $employee->emp_code,
                    'full_name' => $employee->first_name . ($employee->last_name ? ' ' . $employee->last_name : '')
                ];
            });
        
        return view('report::abscences.index', compact('employees', 'client'));
    }
    
    /**
     * Récupérer les données depuis la table daily_attendances pour DataTables
     */
    public function getData(Request $request)
    {
        try {
            $client = Client::where('user_id', auth()->user()->id)->first();
            
            if (!$client) {
                return response()->json(['error' => 'Client non trouvé'], 404);
            }
            
            // Valider les paramètres
            $validator = \Validator::make($request->all(), [
                'start_date' => 'required|date',
                'end_date' => 'required|date|after_or_equal:start_date',
                'emp_code' => 'nullable|string'
            ]);
            
            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()->first()], 400);
            }
            
            // Récupérer les paramètres
            $startDate = $request->input('start_date');
            $endDate = $request->input('end_date');
            $empCode = $request->input('emp_code', 'all');
            
            Log::info("Rapport - Début: {$startDate}, Fin: {$endDate}, Employé: {$empCode}");
            
            // Limiter la période pour éviter les timeouts
            $startDateObj = Carbon::parse($startDate);
            $endDateObj = Carbon::parse($endDate);
            $daysDiff = $startDateObj->diffInDays($endDateObj);
            
            if ($daysDiff > 31) {
                return response()->json([
                    'error' => 'La période ne doit pas dépasser 31 jours. Période sélectionnée: ' . ($daysDiff + 1) . ' jours.'
                ], 400);
            }
            
            // Construire la requête sur daily_attendances
            $query = DailyAttendance::where('client_id', $client->id)
                ->whereBetween('attendance_date', [$startDate, $endDate]);
            
            // Filtrer par employé si nécessaire
            if ($empCode && $empCode !== 'all') {
                $query->where('emp_code', $empCode);
            }
            
            // Récupérer les données
            $attendances = $query->get();
            
            Log::info("Nombre d'enregistrements trouvés dans daily_attendances: " . $attendances->count());
            
            // Transformer les données pour le DataTable
            $reportData = [];
            
            foreach ($attendances as $attendance) {
                // Récupérer les informations de l'employé
                $employee = Employee::where('client_id', $client->id)
                    ->where('emp_code', $attendance->emp_code)
                    ->first();
                
                // Récupérer le planning pour cette date
                $schedule = $this->getEmployeeScheduleForDateNew($employee, $attendance->attendance_date->format('Y-m-d'));
                
                // Vérifier les congés et permissions
                $isOnLeave = $this->isEmployeeOnLeave($attendance->employee_id, $attendance->attendance_date->format('Y-m-d'), collect());
                $hasPermission = $this->hasPermission($attendance->employee_id, $attendance->attendance_date->format('Y-m-d'), collect());
                
                // Déterminer le statut si non défini
                $status = $attendance->status;
                if (!$status) {
                    $status = $this->determineStatus(
                        $schedule,
                        $attendance->attendance_date->isWeekend(),
                        false,
                        $isOnLeave,
                        $hasPermission,
                        $attendance->check_in ? $attendance->check_in->format('H:i:s') : null,
                        $attendance->check_out ? $attendance->check_out->format('H:i:s') : null
                    );
                }
                
                $reportData[] = [
                    'date' => $attendance->attendance_date->format('Y-m-d'),
                    'employee_code' => $attendance->emp_code,
                    'employee_name' => $employee ? $employee->first_name . ($employee->last_name ? ' ' . $employee->last_name : '') : '',
                    'schedule_start' => $schedule && $schedule['start_time'] ? $schedule['start_time'] : '-',
                    'schedule_end' => $schedule && $schedule['end_time'] ? $schedule['end_time'] : '-',
                    'actual_arrival' => $attendance->check_in ? $attendance->check_in->format('H:i:s') : null,
                    'actual_departure' => $attendance->check_out ? $attendance->check_out->format('H:i:s') : null,
                    'late_minutes' => $attendance->late_minutes,
                    'early_leave_minutes' => $attendance->early_leave_minutes,
                    'work_minutes' => $attendance->work_hours ? $attendance->work_hours * 60 : 0,
                    'work_hours' => $attendance->work_hours,
                    'status' => $status,
                    'is_weekend' => $attendance->attendance_date->isWeekend(),
                    'is_holiday' => false,
                    'is_on_leave' => $isOnLeave,
                    'has_permission' => $hasPermission,
                    'all_punches' => $attendance->raw_data ? ($attendance->raw_data['all_punches'] ?? []) : [],
                    'schedule_type' => $schedule ? $schedule['schedule_type'] : 'Non planifié',
                    'is_late' => $attendance->is_late,
                    'is_early_leave' => $attendance->is_early_leave,
                    'schedule_data' => $schedule ? json_encode($schedule) : null,
                ];
            }
            
            Log::info("Rapport généré avec " . count($reportData) . " enregistrements");
            
            // Pagination manuelle pour DataTables
            $totalRecords = count($reportData);
            $start = (int) $request->input('start', 0);
            $length = (int) $request->input('length', 25);
            
            // Trier par date décroissante, puis par employé
            usort($reportData, function($a, $b) {
                if ($a['date'] == $b['date']) {
                    return strcmp($a['employee_code'], $b['employee_code']);
                }
                return strcmp($b['date'], $a['date']);
            });
            
            $pageData = array_slice($reportData, $start, $length);
            
            return response()->json([
                'draw' => (int) $request->input('draw', 1),
                'recordsTotal' => $totalRecords,
                'recordsFiltered' => $totalRecords,
                'data' => $pageData
            ]);
            
        } catch (\Exception $e) {
            Log::error('Erreur génération rapport: ' . $e->getMessage());
            Log::error('Trace: ' . $e->getTraceAsString());
            
            return response()->json([
                'error' => 'Erreur serveur: ' . $e->getMessage(),
                'draw' => (int) $request->input('draw', 1),
                'recordsTotal' => 0,
                'recordsFiltered' => 0,
                'data' => []
            ], 500);
        }
    }
    
    /**
     * Récupérer les transactions d'un device pour une date spécifique
     * (Méthode conservée pour compatibilité mais non utilisée)
     */
    private function getDeviceTransactionsForDate($device, $date, $token, $employees)
    {
        return collect();
    }
    
    /**
     * Grouper les transactions par employé
     * (Méthode conservée pour compatibilité mais non utilisée)
     */
    private function groupTransactionsByEmployee($transactions, $employees)
    {
        return [];
    }
    
    /**
     * Analyser la journée d'un employé
     * (Méthode conservée pour compatibilité mais non utilisée)
     */
    private function analyzeEmployeeDay($employee, $dateStr, $transactions, $permissions, $leaves)
    {
        return null;
    }
    
    /**
     * NOUVELLE MÉTHODE: Récupérer le planning d'un employé pour une date spécifique (supporte 3 types)
     */
    private function getEmployeeScheduleForDateNew($employee, $dateStr)
    {
        if (!$employee) {
            return null;
        }
        
        $date = Carbon::parse($dateStr);
        $dayOfWeek = $date->dayOfWeekIso;
        
        // 1. Chercher d'abord un planning spécifique à la date exacte
        $specificSchedule = EmployeeSchedule::where('client_id', $employee->client_id)
            ->where('employee_id', $employee->id)
            ->where('schedule_date', $dateStr)
            ->first();
        
        if ($specificSchedule) {
            Log::info("Planning spécifique trouvé pour {$employee->emp_code} le {$dateStr} - Type: {$specificSchedule->schedule_type}");
            return $this->formatScheduleData($specificSchedule);
        }
        
        // 2. Chercher un planning dans la plage de dates (start_date - end_date)
        $rangeSchedule = EmployeeSchedule::where('client_id', $employee->client_id)
            ->where('employee_id', $employee->id)
            ->where(function($query) use ($dateStr) {
                $query->where('start_date', '<=', $dateStr)
                      ->where('end_date', '>=', $dateStr);
            })
            ->first();
        
        if ($rangeSchedule) {
            Log::info("Planning dans plage trouvé pour {$employee->emp_code} le {$dateStr} - Type: {$rangeSchedule->schedule_type}");
            return $this->formatScheduleData($rangeSchedule);
        }
        
        // 3. Pour les types FIXE: chercher par jour de semaine
        $fixedSchedule = EmployeeSchedule::where('client_id', $employee->client_id)
            ->where('employee_id', $employee->id)
            ->where('schedule_type', 'fixe')
            ->where('day_of_week', $dayOfWeek)
            ->first();
        
        if ($fixedSchedule) {
            Log::info("Planning fixe trouvé pour {$employee->emp_code} le {$dateStr} (jour {$dayOfWeek})");
            return $this->formatScheduleData($fixedSchedule);
        }
        
        // 4. Pour les types ROTATION: calculer selon le cycle
        $rotationSchedule = EmployeeSchedule::where('client_id', $employee->client_id)
            ->where('employee_id', $employee->id)
            ->where('schedule_type', 'rotation')
            ->first();
        
        if ($rotationSchedule && $rotationSchedule->start_date && $rotationSchedule->end_date) {
            // Vérifier si la date est dans la période de rotation
            $scheduleStart = Carbon::parse($rotationSchedule->start_date);
            $scheduleEnd = Carbon::parse($rotationSchedule->end_date);
            $currentDate = Carbon::parse($dateStr);
            
            if ($currentDate->between($scheduleStart, $scheduleEnd)) {
                // Calculer si c'est un jour de travail dans le cycle
                $daysFromStart = $scheduleStart->diffInDays($currentDate);
                $workDaysCount = $rotationSchedule->work_days_count ?? 1;
                $restDaysCount = $rotationSchedule->rest_days_count ?? 0;
                $cycleLength = $workDaysCount + $restDaysCount;
                
                $positionInCycle = $daysFromStart % $cycleLength;
                
                if ($positionInCycle < $workDaysCount) {
                    Log::info("Planning rotation (jour travail) trouvé pour {$employee->emp_code} le {$dateStr}");
                    return $this->formatScheduleData($rotationSchedule);
                } else {
                    Log::info("Planning rotation (jour repos) trouvé pour {$employee->emp_code} le {$dateStr}");
                    return [
                        'schedule_type' => 'rotation',
                        'is_working_day' => false,
                        'start_time' => null,
                        'end_time' => null,
                        'work_days_count' => $workDaysCount,
                        'rest_days_count' => $restDaysCount
                    ];
                }
            }
        }
        
        // 5. Pour les types PLANIFIE: chercher un planning standard
        $plannedSchedule = EmployeeSchedule::where('client_id', $employee->client_id)
            ->where('employee_id', $employee->id)
            ->where('schedule_type', 'planifie')
            ->first();
        
        if ($plannedSchedule) {
            Log::info("Planning planifié trouvé pour {$employee->emp_code} le {$dateStr}");
            return $this->formatScheduleData($plannedSchedule);
        }
        
        // 6. Dernier recours: chercher n'importe quel planning
        $anySchedule = EmployeeSchedule::where('client_id', $employee->client_id)
            ->where('employee_id', $employee->id)
            ->orderBy('created_at', 'desc')
            ->first();
        
        if ($anySchedule) {
            Log::info("Dernier planning trouvé pour {$employee->emp_code} le {$dateStr} - Type: {$anySchedule->schedule_type}");
            return $this->formatScheduleData($anySchedule);
        }
        
        Log::warning("Aucun planning trouvé pour {$employee->emp_code} le {$dateStr}");
        return null;
    }
    
    /**
     * Formater les données du planning
     */
    private function formatScheduleData($schedule)
    {
        return [
            'schedule_type' => $schedule->schedule_type,
            'is_working_day' => $schedule->is_working_day ?? true,
            'start_time' => $schedule->start_time ? Carbon::parse($schedule->start_time)->format('H:i:s') : null,
            'end_time' => $schedule->end_time ? Carbon::parse($schedule->end_time)->format('H:i:s') : null,
            'work_days_count' => $schedule->work_days_count ?? null,
            'rest_days_count' => $schedule->rest_days_count ?? null,
            'daily_hours' => $schedule->daily_hours ?? null,
            'break_minutes' => $schedule->break_minutes ?? 0,
            'start_date' => $schedule->start_date,
            'end_date' => $schedule->end_date,
        ];
    }
    
    /**
     * Vérifier si c'est un jour férié
     */
    private function isHoliday($date, $clientId)
    {
        // À implémenter selon votre table des jours fériés
        return false;
    }
    
    /**
     * Vérifier si l'employé est en congé
     */
    private function isEmployeeOnLeave($employeeId, $date, $leaves)
    {
        $leave = Leave::where('employee_id', $employeeId)
            ->where('start_date', '<=', $date)
            ->where('end_date', '>=', $date)
            ->first();
        
        return $leave !== null;
    }
    
    /**
     * Vérifier si l'employé a une permission
     */
    private function hasPermission($employeeId, $date, $permissions)
    {
        $permission = EmployeePermission::where('employee_id', $employeeId)
            ->where('date', $date)
            ->where('status', 'approved')
            ->first();
        
        return $permission !== null;
    }
    
    /**
     * Déterminer le statut de présence
     */
    private function determineStatus($schedule, $isWeekend, $isHoliday, $isOnLeave, $hasPermission, $arrivalTime, $departureTime)
    {
        // 1. Si jour férié
        if ($isHoliday) {
            return 'holiday';
        }
        
        // 2. Si en congé
        if ($isOnLeave) {
            return 'leave';
        }
        
        // 3. Si permission
        if ($hasPermission) {
            return 'permission';
        }
        
        // 4. Si pas d'horaire prévu
        if (!$schedule) {
            // Si weekend sans planning
            if ($isWeekend) {
                return 'weekend';
            }
            // Si jour de semaine sans planning
            return 'no_schedule';
        }
        
        // 5. Si jour non travaillé dans le planning
        if ($schedule['is_working_day'] === false) {
            return 'day_off';
        }
        
        // 6. Si weekend mais avec planning de travail
        if ($isWeekend && $schedule['is_working_day'] === true) {
            // Weekend mais prévu pour travailler
            if ($arrivalTime || $departureTime) {
                return 'present';
            } else {
                return 'absent';
            }
        }
        
        // 7. Si présent (au moins un pointage)
        if ($arrivalTime !== null || $departureTime !== null) {
            return 'present';
        }
        
        // 8. Si absence justifiée (à implémenter si besoin)
        
        // 9. Sinon absent
        return 'absent';
    }
    
    /**
     * Exporter le rapport en Excel
     */
    public function export(Request $request)
    {
        // À implémenter selon vos besoins
    }

    /**
     * Déterminer si un employé est en retard selon différentes règles
     */
    private function calculateLateStatus($employee, $dateStr, $schedule, $arrivalTime, $departureTime)
    {
        if (!$schedule || !$schedule['start_time']) {
            return [
                'late_minutes' => 0,
                'is_late' => false,
                'late_reason' => 'Pas de planning'
            ];
        }
        
        $scheduleStart = Carbon::createFromFormat('H:i:s', $schedule['start_time']);
        $lateMinutes = 0;
        $isLate = false;
        $lateReason = '';
        
        // RÈGLE 1: Si arrivée enregistrée après start_time
        if ($arrivalTime) {
            $actualArrival = Carbon::createFromFormat('H:i:s', $arrivalTime);
            
            if ($actualArrival > $scheduleStart) {
                $lateMinutes = $actualArrival->diffInMinutes($scheduleStart);
                $isLate = true;
                $lateReason = 'Arrivée tardive';
                
                // Vérifier la tolérance (ex: 5 minutes de grâce)
                $toleranceMinutes = 5; // À configurer
                if ($lateMinutes <= $toleranceMinutes) {
                    $isLate = false;
                    $lateReason = 'Dans la tolérance';
                }
            }
        }
        // RÈGLE 2: Si pas d'arrivée mais départ enregistré (pointage manqué le matin)
        else if ($departureTime) {
            $actualDeparture = Carbon::createFromFormat('H:i:s', $departureTime);
            
            // Si le départ est après midi, considérer comme retard
            if ($actualDeparture->hour >= 12) {
                $lateMinutes = 240; // 4 heures par défaut (matinée manquée)
                $isLate = true;
                $lateReason = 'Pointage matin manqué';
            }
        }
        // RÈGLE 3: Si aucun pointage mais jour ouvré
        else {
            $now = Carbon::now();
            $currentTime = Carbon::createFromTime($now->hour, $now->minute, 0);
            
            // Si nous sommes après l'heure de début + marge
            $marginMinutes = 30; // Marge avant de considérer absent
            $cutoffTime = $scheduleStart->copy()->addMinutes($marginMinutes);
            
            if ($currentTime > $cutoffTime) {
                $lateMinutes = $currentTime->diffInMinutes($scheduleStart);
                $isLate = true;
                $lateReason = 'Absence avec retard';
            }
        }
        
        // RÈGLE 4: Vérifier les permissions pour la matinée
        if ($isLate) {
            $hasMorningPermission = $this->hasMorningPermission($employee->id, $dateStr);
            if ($hasMorningPermission) {
                $isLate = false;
                $lateReason = 'Permission matin';
                $lateMinutes = 0;
            }
        }
        
        return [
            'late_minutes' => $lateMinutes,
            'is_late' => $isLate,
            'late_reason' => $lateReason
        ];
    }
    
    /**
     * Vérifier si l'employé a une permission pour la matinée
     */
    private function hasMorningPermission($employeeId, $date)
    {
        $permission = EmployeePermission::where('employee_id', $employeeId)
            ->where('date', $date)
            ->where('status', 'approved')
            ->where(function($query) {
                $query->where('start_time', '<', '12:00:00')
                      ->orWhereNull('start_time');
            })
            ->first();
        
        return $permission !== null;
    }
    
    /**
     * Debug: Voir ce que retourne getData()
     */
    public function debugGetData(Request $request)
    {
        try {
            $client = Client::where('user_id', auth()->user()->id)->first();
            
            if (!$client) {
                return response()->json(['error' => 'Client non trouvé'], 404);
            }
            
            // Simuler les paramètres
            $request->merge([
                'start_date' => Carbon::now()->subDays(7)->format('Y-m-d'),
                'end_date' => Carbon::now()->format('Y-m-d'),
                'emp_code' => 'all',
                'draw' => 1,
                'start' => 0,
                'length' => 25
            ]);
            
            // Appeler la méthode getData
            $response = $this->getData($request);
            $data = json_decode($response->getContent(), true);
            
            return response()->json([
                'success' => true,
                'controller_response' => $data,
                'message' => 'Test réussi',
                'daily_attendances_count' => DailyAttendance::where('client_id', $client->id)->count(),
                'employees_count' => Employee::where('client_id', $client->id)->count()
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ], 500);
        }
    }
    
    /**
     * Exporter le rapport en PDF
     */
    public function exportPdf(Request $request)
    {
        try {
            $client = Client::where('user_id', auth()->user()->id)->first();
            
            if (!$client) {
                return redirect()->back()->with('error', 'Client non trouvé.');
            }
            
            // Valider les paramètres
            $validator = \Validator::make($request->all(), [
                'start_date' => 'required|date',
                'end_date' => 'required|date|after_or_equal:start_date',
                'emp_code' => 'nullable|string'
            ]);
            
            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            
            // Récupérer les paramètres
            $start_date = $request->input('start_date');
            $end_date = $request->input('end_date');
            $emp_code = $request->input('emp_code', 'all');
            
            Log::info("Export PDF - Début: {$start_date}, Fin: {$end_date}, Employé: {$emp_code}");
            
            // Construire la requête sur daily_attendances
            $query = DailyAttendance::where('client_id', $client->id)
                ->whereBetween('attendance_date', [$start_date, $end_date]);
            
            // Filtrer par employé si nécessaire
            if ($emp_code && $emp_code !== 'all') {
                $query->where('emp_code', $emp_code);
            }
            
            // Récupérer les données
            $attendances = $query->get();
            
            // Transformer les données pour le rapport
            $reportData = [];
            
            foreach ($attendances as $attendance) {
                // Récupérer les informations de l'employé
                $employee = Employee::where('client_id', $client->id)
                    ->where('emp_code', $attendance->emp_code)
                    ->first();
                
                // Récupérer le planning pour cette date
                $schedule = $this->getEmployeeScheduleForDateNew($employee, $attendance->attendance_date->format('Y-m-d'));
                
                // Vérifier les congés et permissions
                $isOnLeave = $this->isEmployeeOnLeave($attendance->employee_id, $attendance->attendance_date->format('Y-m-d'), collect());
                $hasPermission = $this->hasPermission($attendance->employee_id, $attendance->attendance_date->format('Y-m-d'), collect());
                
                // Déterminer le statut si non défini
                $status = $attendance->status;
                if (!$status) {
                    $status = $this->determineStatus(
                        $schedule,
                        $attendance->attendance_date->isWeekend(),
                        false,
                        $isOnLeave,
                        $hasPermission,
                        $attendance->check_in ? $attendance->check_in->format('H:i:s') : null,
                        $attendance->check_out ? $attendance->check_out->format('H:i:s') : null
                    );
                }
                
                $reportData[] = [
                    'date' => $attendance->attendance_date->format('Y-m-d'),
                    'employee_code' => $attendance->emp_code,
                    'employee_name' => $employee ? $employee->first_name . ($employee->last_name ? ' ' . $employee->last_name : '') : '',
                    'schedule_start' => $schedule && $schedule['start_time'] ? $schedule['start_time'] : '-',
                    'schedule_end' => $schedule && $schedule['end_time'] ? $schedule['end_time'] : '-',
                    'actual_arrival' => $attendance->check_in ? $attendance->check_in->format('H:i:s') : null,
                    'actual_departure' => $attendance->check_out ? $attendance->check_out->format('H:i:s') : null,
                    'late_minutes' => $attendance->late_minutes,
                    'early_leave_minutes' => $attendance->early_leave_minutes,
                    'work_minutes' => $attendance->work_hours ? $attendance->work_hours * 60 : 0,
                    'work_hours' => $attendance->work_hours,
                    'status' => $status,
                    'is_weekend' => $attendance->attendance_date->isWeekend(),
                    'is_holiday' => false,
                    'is_on_leave' => $isOnLeave,
                    'has_permission' => $hasPermission,
                    'all_punches' => $attendance->raw_data ? ($attendance->raw_data['all_punches'] ?? []) : [],
                    'schedule_type' => $schedule ? $schedule['schedule_type'] : 'Non planifié',
                    'is_late' => $attendance->is_late,
                    'is_early_leave' => $attendance->is_early_leave,
                ];
            }
            
            // Grouper les données par employé pour l'affichage
            $groupedData = [];
            foreach ($reportData as $record) {
                $empCode = $record['employee_code'];
                
                if (!isset($groupedData[$empCode])) {
                    $employee = Employee::where('emp_code', $empCode)->first();
                    $groupedData[$empCode] = [
                        'employee' => $employee,
                        'records' => []
                    ];
                }
                
                $groupedData[$empCode]['records'][] = $record;
            }
            
            // Trier les employés par code
            ksort($groupedData);
            
            // Trier les enregistrements de chaque employé par date
            foreach ($groupedData as &$employeeData) {
                usort($employeeData['records'], function($a, $b) {
                    return strcmp($b['date'], $a['date']);
                });
            }
            
            // Données pour le PDF
            $data = [
                'start_date' => $start_date,
                'end_date' => $end_date,
                'export_date' => Carbon::now(),
                'client' => $client,
                'filters' => [
                    'emp_code' => $emp_code === 'all' ? 'Tous les employés' : $emp_code
                ],
                'total_employees' => count($groupedData),
                'total_records' => count($reportData),
                'grouped_data' => $groupedData,
            ];
            
            // Générer le PDF
            $pdf = Pdf::loadView('report::abscences.exports.pdf', $data);
            
            // Nom du fichier
            $filename = 'rapport_absences_retards_' . Carbon::now()->format('Y-m-d_H-i-s') . '.pdf';
            
            // Options du PDF
            $pdf->setPaper('A4', 'portrait');
            
            return $pdf->download($filename);
            
        } catch (\Exception $e) {
            Log::error('Erreur export PDF: ' . $e->getMessage());
            Log::error('Trace: ' . $e->getTraceAsString());
            
            return redirect()->back()->with('error', 'Erreur lors de la génération du PDF: ' . $e->getMessage());
        }
    }
    
    /**
     * Afficher le PDF dans le navigateur (prévisualisation)
     */
    public function previewPdf(Request $request)
    {
        try {
            $client = Client::where('user_id', auth()->user()->id)->first();
            
            if (!$client) {
                return response()->json(['error' => 'Client non trouvé'], 404);
            }
            
            // Valider les paramètres
            $validator = \Validator::make($request->all(), [
                'start_date' => 'required|date',
                'end_date' => 'required|date|after_or_equal:start_date',
                'emp_code' => 'nullable|string'
            ]);
            
            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()->first()], 400);
            }
            
            // Récupérer les paramètres
            $start_date = $request->input('start_date');
            $end_date = $request->input('end_date');
            $emp_code = $request->input('emp_code', 'all');
            
            // Récupérer les données réelles depuis daily_attendances
            $query = DailyAttendance::where('client_id', $client->id)
                ->whereBetween('attendance_date', [$start_date, $end_date]);
            
            if ($emp_code && $emp_code !== 'all') {
                $query->where('emp_code', $emp_code);
            }
            
            $attendances = $query->get();
            
            // Transformer les données
            $reportData = [];
            foreach ($attendances as $attendance) {
                $employee = Employee::where('client_id', $client->id)
                    ->where('emp_code', $attendance->emp_code)
                    ->first();
                
                $reportData[] = [
                    'date' => $attendance->attendance_date->format('Y-m-d'),
                    'employee_code' => $attendance->emp_code,
                    'employee_name' => $employee ? $employee->first_name . ' ' . $employee->last_name : '',
                    'schedule_start' => '-',
                    'schedule_end' => '-',
                    'actual_arrival' => $attendance->check_in ? $attendance->check_in->format('H:i:s') : null,
                    'actual_departure' => $attendance->check_out ? $attendance->check_out->format('H:i:s') : null,
                    'late_minutes' => $attendance->late_minutes,
                    'early_leave_minutes' => $attendance->early_leave_minutes,
                    'work_hours' => $attendance->work_hours,
                    'status' => $attendance->status,
                ];
            }
            
            // Grouper les données par employé
            $groupedData = [];
            foreach ($reportData as $record) {
                $empCode = $record['employee_code'];
                if (!isset($groupedData[$empCode])) {
                    $employee = Employee::where('emp_code', $empCode)->first();
                    $groupedData[$empCode] = [
                        'employee' => $employee,
                        'records' => []
                    ];
                }
                $groupedData[$empCode]['records'][] = $record;
            }
            
            $data = [
                'start_date' => $start_date,
                'end_date' => $end_date,
                'export_date' => Carbon::now(),
                'client' => $client,
                'filters' => [
                    'emp_code' => $emp_code === 'all' ? 'Tous les employés' : $emp_code
                ],
                'total_employees' => count($groupedData),
                'total_records' => count($reportData),
                'grouped_data' => $groupedData,
            ];
            
            $pdf = Pdf::loadView('report::abscences.exports.pdf', $data);
            
            return $pdf->stream('preview_rapport.pdf');
            
        } catch (\Exception $e) {
            Log::error('Erreur prévisualisation PDF: ' . $e->getMessage());
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
    
    /**
     * Générer des données d'exemple pour la prévisualisation
     */
    private function generateSampleData()
    {
        $sampleData = [];
        
        // Exemple d'employés
        $sampleEmployees = [
            (object)[
                'emp_code' => 'EMP001',
                'first_name' => 'Jean',
                'last_name' => 'Dupont'
            ],
            (object)[
                'emp_code' => 'EMP002',
                'first_name' => 'Marie',
                'last_name' => 'Martin'
            ],
            (object)[
                'emp_code' => 'EMP003',
                'first_name' => 'Pierre',
                'last_name' => 'Durand'
            ]
        ];
        
        // Dates d'exemple
        $startDate = Carbon::parse('2024-01-01');
        $endDate = Carbon::parse('2024-01-05');
        
        foreach ($sampleEmployees as $employee) {
            $empCode = $employee->emp_code;
            $records = [];
            
            $currentDate = $startDate->copy();
            while ($currentDate <= $endDate) {
                $dateStr = $currentDate->format('Y-m-d');
                $dayOfWeek = $currentDate->dayOfWeekIso;
                
                // Générer des données aléatoires mais réalistes
                $isWeekend = in_array($dayOfWeek, [6, 7]);
                
                $record = [
                    'date' => $dateStr,
                    'employee_code' => $empCode,
                    'employee_name' => $employee->first_name . ' ' . $employee->last_name,
                    'schedule_start' => $isWeekend ? '-' : '08:00',
                    'schedule_end' => $isWeekend ? '-' : '17:00',
                    'actual_arrival' => $isWeekend ? null : ($dayOfWeek === 2 ? '08:45' : '08:15'),
                    'actual_departure' => $isWeekend ? null : ($dayOfWeek === 3 ? '16:30' : '17:10'),
                    'late_minutes' => $isWeekend ? null : ($dayOfWeek === 2 ? 45 : 0),
                    'early_leave_minutes' => $isWeekend ? null : ($dayOfWeek === 3 ? 30 : 0),
                    'work_minutes' => $isWeekend ? 0 : 540,
                    'status' => $isWeekend ? 'weekend' : ($dayOfWeek === 4 ? 'leave' : 'present'),
                    'is_weekend' => $isWeekend,
                    'is_holiday' => false,
                    'is_on_leave' => $dayOfWeek === 4,
                    'has_permission' => false,
                    'all_punches' => $isWeekend ? [] : ['08:15:00', '12:00:00', '13:00:00', '17:10:00'],
                    'schedule_type' => $isWeekend ? 'Non planifié' : 'Fixe',
                    'is_late' => $dayOfWeek === 2,
                    'has_start_time' => !$isWeekend,
                    'has_end_time' => !$isWeekend,
                    'has_any_attendance' => !$isWeekend,
                    'has_both_times' => !$isWeekend && $dayOfWeek !== 4
                ];
                
                $records[] = $record;
                $currentDate->addDay();
            }
            
            $sampleData[$empCode] = [
                'employee' => $employee,
                'records' => $records
            ];
        }
        
        return $sampleData;
    }
}