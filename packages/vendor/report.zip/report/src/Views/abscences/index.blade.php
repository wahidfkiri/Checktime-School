@extends('layouts.app')

@section('content')
<div id="main" class="layout-navbar navbar-fixed">
    <x-nav-bar />
    <div id="main-content">
        <div class="page-heading">
            <div class="page-title">
                <div class="row">
                    <div class="col-12 col-md-6 order-md-1 order-last">
                        <h3>Rapport Absences & Retards</h3>
                        <p class="text-subtitle text-muted">Analyse des présences à partir des données quotidiennes</p>
                    </div>
                </div>
            </div>

            <section class="section">
                <div class="card">
                    <div class="card-header">
                        <!-- Filtres -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <h6 class="card-title">Filtres du rapport</h6>
                                        <!-- Formulaire pour PDF -->
                                        <form id="exportPdfForm" action="{{ route('admin.reports.export.pdf') }}" method="POST" style="display: none;">
                                            @csrf
                                            <input type="hidden" name="start_date" id="pdf_start_date">
                                            <input type="hidden" name="end_date" id="pdf_end_date">
                                            <input type="hidden" name="emp_code" id="pdf_emp_code">
                                        </form>
                                        
                                        <div class="row g-3">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="report_start_date" class="form-label">Date début</label>
                                                    <input type="date" class="form-control" id="report_start_date" 
                                                           value="{{ date('Y-m-d', strtotime('-7 days')) }}">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="report_end_date" class="form-label">Date fin</label>
                                                    <input type="date" class="form-control" id="report_end_date" 
                                                           value="{{ date('Y-m-d') }}">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="report_emp_code" class="form-label">Employé</label>
                                                    <select class="form-control" id="report_emp_code">
                                                        <option value="all">Tous les employés</option>
                                                        @foreach($employees as $employee)
                                                            <option value="{{ $employee['emp_code'] }}">
                                                                {{ $employee['emp_code'] }} - {{ $employee['full_name'] }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group text-start">
                                                    <label class="form-label d-block" style="margin-bottom:0px;">&nbsp;</label>
                                                    <div class="d-flex flex-wrap gap-2">
                                                        <button type="button" class="btn btn-primary" id="generate_report">
                                                            <i class="bi bi-file-earmark-text me-1"></i> Générer
                                                        </button>
                                                        <button type="button" class="btn btn-success" id="export_excel">
                                                            <i class="bi bi-file-excel me-1"></i> Excel
                                                        </button>
                                                        <button type="button" class="btn btn-danger" id="export_pdf">
                                                            <i class="bi bi-file-pdf me-1"></i> PDF
                                                        </button>
                                                        <button type="button" class="btn btn-info" id="preview_pdf">
                                                            <i class="bi bi-eye me-1"></i> Prévisualiser
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-md-12">
                                                <div class="alert alert-info alert-sm p-2 mb-0">
                                                    <i class="bi bi-info-circle me-1"></i>
                                                    Données chargées depuis la table <strong>daily_attendances</strong>.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card-body">
                        <!-- Résumé statistique -->
                        <div id="report-summary" class="row mb-3 d-none">
                            <div class="col-md-12">
                                <div class="card border-success">
                                    <div class="card-body">
                                        <h6 class="card-title">📊 Résumé du rapport</h6>
                                        <div class="row text-center">
                                            <div class="col-md-2 col-sm-4 mb-2">
                                                <div class="border rounded p-2 bg-light">
                                                    <h5 class="mb-0" id="total-days">0</h5>
                                                    <small class="text-muted">Jours analysés</small>
                                                </div>
                                            </div>
                                            <div class="col-md-2 col-sm-4 mb-2">
                                                <div class="border rounded p-2 bg-light">
                                                    <h5 class="mb-0 text-success" id="present-count">0</h5>
                                                    <small class="text-muted">Présences</small>
                                                </div>
                                            </div>
                                            <div class="col-md-2 col-sm-4 mb-2">
                                                <div class="border rounded p-2 bg-light">
                                                    <h5 class="mb-0 text-danger" id="absent-count">0</h5>
                                                    <small class="text-muted">Absences</small>
                                                </div>
                                            </div>
                                            <div class="col-md-2 col-sm-4 mb-2">
                                                <div class="border rounded p-2 bg-light">
                                                    <h5 class="mb-0 text-warning" id="late-count">0</h5>
                                                    <small class="text-muted">Retards</small>
                                                </div>
                                            </div>
                                            <div class="col-md-2 col-sm-4 mb-2">
                                                <div class="border rounded p-2 bg-light">
                                                    <h5 class="mb-0 text-info" id="leave-count">0</h5>
                                                    <small class="text-muted">Congés</small>
                                                </div>
                                            </div>
                                            <div class="col-md-2 col-sm-4 mb-2">
                                                <div class="border rounded p-2 bg-light">
                                                    <h5 class="mb-0 text-secondary" id="permission-count">0</h5>
                                                    <small class="text-muted">Permissions</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Chargement -->
                        <div class="alert alert-info alert-dismissible fade show d-none" id="report-loading" role="alert">
                            <div class="d-flex align-items-center">
                                <div class="spinner-border spinner-border-sm me-2" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <strong id="report-loading-message">Chargement des données en cours...</strong>
                            </div>
                        </div>
                        
                        <!-- Tableau -->
                        <div class="table-responsive">
                            <table id="report-table" class="table table-striped table-hover" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Code</th>
                                        <th>Employé</th>
                                        <th>Planning</th>
                                        <th>Arrivée</th>
                                        <th>Départ</th>
                                        <th>Retard (min)</th>
                                        <th>Départ anticipé (min)</th>
                                        <th>Heures travaillées</th>
                                        <th>Statut</th>
                                        <th>Observations</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                        
                        <!-- Pied de tableau avec informations -->
                        <div class="row mt-3">
                            <div class="col-md-12">
                                <div class="alert alert-secondary p-2 small">
                                    <i class="bi bi-info-circle me-1"></i>
                                    <strong>Légende :</strong>
                                    <span class="badge bg-success ms-2">Présent</span>
                                    <span class="badge bg-warning ms-1">Retard</span>
                                    <span class="badge bg-danger ms-1">Absent</span>
                                    <span class="badge bg-info ms-1">Congé</span>
                                    <span class="badge bg-secondary ms-1">Weekend/Repos</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.bootstrap5.min.css">

<script>
$(document).ready(function() {
    // Variables
    var reportTable;
    
    // Fonctions utilitaires
    function showReportLoading(message) {
        $('#report-loading-message').text(message || 'Chargement des données en cours...');
        $('#report-loading').removeClass('d-none');
    }
    
    function hideReportLoading() {
        $('#report-loading').addClass('d-none');
    }
    
    function showSweetAlert(icon, title, text, showConfirm = false) {
        if (showConfirm) {
            return Swal.fire({
                icon: icon,
                title: title,
                html: text,
                showCancelButton: true,
                confirmButtonText: 'Oui, continuer',
                cancelButtonText: 'Annuler'
            });
        } else {
            Swal.fire({
                icon: icon,
                title: title,
                html: text,
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });
        }
    }
    
    // Mettre à jour le résumé
    function updateReportSummary(data) {
        var present = 0;
        var presentLate = 0;
        var absent = 0;
        var leave = 0;
        var permission = 0;
        var days = new Set();
        
        data.forEach(function(row) {
            days.add(row.date);
            
            if (row.status === 'present') {
                if (row.is_late) {
                    presentLate++;
                } else {
                    present++;
                }
            } else {
                switch(row.status) {
                    case 'absent': absent++; break;
                    case 'leave': leave++; break;
                    case 'permission': permission++; break;
                }
            }
        });
        
        $('#total-days').text(days.size);
        $('#present-count').text(present);
        $('#absent-count').text(absent);
        $('#late-count').text(presentLate);
        $('#leave-count').text(leave);
        $('#permission-count').text(permission);
        
        $('#report-summary').removeClass('d-none');
    }

    // Formater les heures
    function formatHours(hours) {
        if (!hours && hours !== 0) return '-';
        if (hours === 0) return '0h';
        
        var h = Math.floor(hours);
        var m = Math.round((hours - h) * 60);
        
        if (m === 0) {
            return h + 'h';
        } else {
            return h + 'h ' + m + 'min';
        }
    }

    // Formater les minutes
    function formatMinutes(minutes) {
        if (minutes === null || minutes === undefined) return '-';
        if (minutes === 0) return '0';
        return minutes;
    }
    
    // Valider les dates avant export
    function validateDatesForExport() {
        var startDate = $('#report_start_date').val();
        var endDate = $('#report_end_date').val();
        
        if (!startDate || !endDate) {
            showSweetAlert('error', 'Erreur', 'Veuillez sélectionner une période.');
            return false;
        }
        
        if (new Date(startDate) > new Date(endDate)) {
            showSweetAlert('error', 'Erreur', 'La date de début ne peut pas être après la date de fin.');
            return false;
        }
        
        var daysDiff = Math.ceil((new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24)) + 1;
        if (daysDiff > 31) {
            showSweetAlert('warning', 'Attention', 
                'La période ne doit pas dépasser 31 jours. ' +
                'Période sélectionnée: ' + daysDiff + ' jours.');
            return false;
        }
        
        return true;
    }
    
    // Initialiser DataTable
    function initReportTable() {
        reportTable = $('#report-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.reports.data') }}",
                type: 'GET',
                data: function(d) {
                    return {
                        start_date: $('#report_start_date').val(),
                        end_date: $('#report_end_date').val(),
                        emp_code: $('#report_emp_code').val(),
                        draw: d.draw,
                        start: d.start,
                        length: d.length,
                        order: d.order,
                        columns: d.columns,
                        search: d.search
                    };
                },
                beforeSend: function() {
                    showReportLoading('Chargement des données...');
                },
                complete: function() {
                    hideReportLoading();
                },
                error: function(xhr) {
                    hideReportLoading();
                    var errorMsg = xhr.responseJSON?.error || 'Erreur de chargement des données';
                    showSweetAlert('error', 'Erreur', errorMsg);
                },
                dataSrc: function(json) {
                    if (json.error) {
                        showSweetAlert('error', 'Erreur', json.error);
                        return [];
                    }
                    
                    if (json.data) {
                        updateReportSummary(json.data);
                        return json.data;
                    }
                    
                    return [];
                }
            },
            columns: [
                { 
                    data: 'date',
                    render: function(data) {
                        return data ? new Date(data).toLocaleDateString('fr-FR') : '-';
                    }
                },
                { 
                    data: 'employee_code',
                    render: function(data) {
                        return data || '-';
                    }
                },
                { 
                    data: 'employee_name',
                    render: function(data) {
                        return data || '-';
                    }
                },
                { 
                    data: null,
                    render: function(data) {
                        if (data.schedule_start === '-' && data.schedule_end === '-') {
                            return 'Non planifié';
                        } else {
                            return data.schedule_start + ' - ' + data.schedule_end;
                        }
                    }
                },
                { 
                    data: 'actual_arrival',
                    render: function(data) {
                        return data || '-';
                    }
                },
                { 
                    data: 'actual_departure',
                    render: function(data) {
                        return data || '-';
                    }
                },
                { 
                    data: 'late_minutes',
                    render: function(data, type, row) {
                        if (!row.actual_arrival && !row.actual_departure) return '-';
                        if (data === null || data === undefined) return '-';
                        
                        if (data === 0) {
                            return '<span class="text-success">À l\'heure</span>';
                        }
                        
                        return '<span class="text-danger">' + formatMinutes(data) + '</span>';
                    }
                },
                { 
                    data: 'early_leave_minutes',
                    render: function(data, type, row) {
                        if (!row.actual_arrival && !row.actual_departure) return '-';
                        if (data === null || data === undefined) return '-';
                        
                        if (data === 0) {
                            return '<span class="text-success">Normal</span>';
                        }
                        
                        return '<span class="text-warning">' + formatMinutes(data) + '</span>';
                    }
                },
                { 
                    data: 'work_hours',
                    render: function(data) {
                        return formatHours(data);
                    }
                },
                { 
                    data: 'status',
                    render: function(data, type, row) {
                        var badgeClass = 'secondary';
                        var text = data;
                        
                        switch(data) {
                            case 'present':
                                if (row.is_late) {
                                    badgeClass = 'warning';
                                    text = 'Retard';
                                } else {
                                    badgeClass = 'success';
                                    text = 'Présent';
                                }
                                break;
                            case 'absent':
                                badgeClass = 'danger';
                                text = 'Absent';
                                break;
                            case 'leave':
                                badgeClass = 'info';
                                text = 'Congé';
                                break;
                            case 'permission':
                                badgeClass = 'warning';
                                text = 'Permission';
                                break;
                            case 'weekend':
                                text = 'Weekend';
                                badgeClass = 'secondary';
                                break;
                            case 'holiday':
                                badgeClass = 'success';
                                text = 'Férié';
                                break;
                            case 'day_off':
                                badgeClass = 'secondary';
                                text = 'Repos';
                                break;
                            case 'no_schedule':
                                text = 'Non planifié';
                                badgeClass = 'light text-dark';
                                break;
                        }
                        
                        return '<span class="badge bg-' + badgeClass + '">' + text + '</span>';
                    }
                },
                { 
                    data: null,
                    render: function(data) {
                        var observations = [];
                        
                        if (data.is_weekend) observations.push('Weekend');
                        if (data.is_holiday) observations.push('Férié');
                        if (data.is_on_leave) observations.push('Congé');
                        if (data.has_permission) observations.push('Permission');
                        
                        if (data.all_punches && data.all_punches.length > 0) {
                            observations.push(data.all_punches.length + ' pointage(s)');
                        }
                        
                        return observations.join(', ') || '-';
                    }
                }
            ],
            language: {
                url: "//cdn.datatables.net/plug-ins/1.10.25/i18n/French.json"
            },
            pageLength: 25,
            order: [[0, 'desc']],
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'excel',
                    text: '<i class="bi bi-file-excel me-1"></i> Excel',
                    className: 'btn btn-success btn-sm',
                    title: 'Rapport Absences Retards',
                    messageTop: function() {
                        var startDate = $('#report_start_date').val();
                        var endDate = $('#report_end_date').val();
                        var empCode = $('#report_emp_code').val();
                        var empName = $('#report_emp_code option:selected').text();
                        
                        return 'Période: ' + startDate + ' au ' + endDate + '\n' +
                               'Employé: ' + empName + '\n' +
                               'Généré le: ' + new Date().toLocaleDateString('fr-FR');
                    },
                    exportOptions: {
                        columns: ':visible'
                    }
                },
                {
                    extend: 'print',
                    text: '<i class="bi bi-printer me-1"></i> Imprimer',
                    className: 'btn btn-secondary btn-sm',
                    title: 'Rapport Absences Retards',
                    messageTop: function() {
                        var startDate = $('#report_start_date').val();
                        var endDate = $('#report_end_date').val();
                        var empCode = $('#report_emp_code').val();
                        var empName = $('#report_emp_code option:selected').text();
                        
                        return '<h4>Rapport Absences et Retards</h4>' +
                               '<p>Période: ' + startDate + ' au ' + endDate + '</p>' +
                               '<p>Employé: ' + empName + '</p>' +
                               '<p>Généré le: ' + new Date().toLocaleDateString('fr-FR') + '</p><hr>';
                    },
                    exportOptions: {
                        columns: ':visible',
                        stripHtml: false
                    }
                },
                {
                    extend: 'colvis',
                    text: '<i class="bi bi-eye me-1"></i> Colonnes',
                    className: 'btn btn-info btn-sm'
                }
            ],
            drawCallback: function() {
                $('[data-bs-toggle="tooltip"]').tooltip();
            }
        });
    }
    
    // Initialisation
    initReportTable();
    
    // Générer le rapport
    $('#generate_report').on('click', function() {
        if (!validateDatesForExport()) return;
        reportTable.ajax.reload();
    });
    
    // Exporter en Excel
    $('#export_excel').on('click', function() {
        $('.buttons-excel').click();
    });
    
    // Exporter en PDF
    $('#export_pdf').on('click', function() {
        if (!validateDatesForExport()) return;
        
        var startDate = $('#report_start_date').val();
        var endDate = $('#report_end_date').val();
        var empCode = $('#report_emp_code').val();
        var empName = $('#report_emp_code option:selected').text();
        
        var message = 'Êtes-vous sûr de vouloir exporter en PDF ?<br><br>' +
                     '<strong>Période :</strong> ' + startDate + ' au ' + endDate + '<br>' +
                     '<strong>Employé :</strong> ' + empName;
        
        showSweetAlert('question', 'Exporter en PDF', message, true).then((result) => {
            if (result.isConfirmed) {
                $('#pdf_start_date').val(startDate);
                $('#pdf_end_date').val(endDate);
                $('#pdf_emp_code').val(empCode);
                
                showSweetAlert('info', 'Génération en cours', 'Le PDF est en cours de génération...');
                
                $('#exportPdfForm').submit();
            }
        });
    });
    
    // Prévisualiser PDF
    $('#preview_pdf').on('click', function() {
        if (!validateDatesForExport()) return;
        
        var startDate = $('#report_start_date').val();
        var endDate = $('#report_end_date').val();
        var empCode = $('#report_emp_code').val();
        
        var url = "{{ route('admin.reports.preview.pdf') }}";
        var params = new URLSearchParams({
            start_date: startDate,
            end_date: endDate,
            emp_code: empCode,
            _token: "{{ csrf_token() }}"
        });
        
        window.open(url + '?' + params.toString(), '_blank');
    });
    
    // Appliquer automatiquement quand on change les filtres
    $('#report_start_date, #report_end_date, #report_emp_code').on('change', function() {
        $('#generate_report').click();
    });
    
    // Initialiser les tooltips
    $(function () {
        $('[data-bs-toggle="tooltip"]').tooltip();
    });
});
</script>

<style>
    .card-header { background-color: #f8f9fa; }
    .table th { background-color: #f8f9fa; font-weight: 600; }
    .btn-group .btn { border-radius: 0.375rem !important; }
    
    .btn-export {
        min-width: 120px;
    }
    
    @media (max-width: 768px) {
        .d-flex.flex-wrap {
            flex-direction: column;
        }
        .d-flex.flex-wrap .btn {
            width: 100%;
            margin-bottom: 5px;
        }
        .btn-group { flex-direction: column; gap: 5px; }
    }
    
    #report-table th {
        white-space: nowrap;
        background-color: #f1f5f9;
    }
    
    #report-table td {
        vertical-align: middle;
    }
    
    .badge {
        font-size: 0.8em;
        font-weight: 500;
    }
    
    @media (max-width: 768px) {
        .table-responsive {
            font-size: 0.85rem;
        }
        
        #report-table th,
        #report-table td {
            padding: 0.5rem;
        }
    }
    
    #report-table td:empty::before {
        content: "-";
        color: #6c757d;
    }
    
    .hour-cell {
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }
    
    #report-summary .border {
        transition: all 0.3s ease;
    }
    
    #report-summary .border:hover {
        transform: translateY(-2px);
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    
    /* Couleurs des badges */
    .bg-success { background-color: #198754 !important; }
    .bg-danger { background-color: #dc3545 !important; }
    .bg-warning { background-color: #ffc107 !important; color: #000 !important; }
    .bg-info { background-color: #0dcaf0 !important; color: #000 !important; }
    .bg-secondary { background-color: #6c757d !important; }
    .bg-light { background-color: #f8f9fa !important; }
</style>
@endsection