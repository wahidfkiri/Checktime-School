<?php

namespace Vendor\Attendance\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Employee;
use App\Models\Client;
use App\Models\Device; 
use App\Models\DailyAttendance;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;
use Carbon\Carbon;
use Illuminate\Support\Collection;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Services\AttendanceSyncService;

class DailyAttendanceController extends Controller
{
    private AttendanceSyncService $attendanceService;

    public function __construct(AttendanceSyncService $attendanceService)
    {
        $this->attendanceService = $attendanceService;
    }
    
    /**
     * Afficher la page des pointages
     */
    public function index(Request $request)
    {
        $client = Client::where('user_id', auth()->user()->id)->first();
        
        if (!$client) {
            return redirect()->route('home')->with('error', 'Client non trouvé.');
        }
        
        // Synchroniser les données d'aujourd'hui avant d'afficher
        try {
            $this->attendanceService->updateDailySummariesForToday($client);
            Log::info("Données synchronisées pour aujourd'hui - Client: {$client->id}");
        } catch (\Exception $e) {
            Log::error("Erreur synchronisation: " . $e->getMessage());
        }
        
        // Récupérer les devices pour les filtres
        $devices = Device::where('client_id', $client->id)
            ->orderBy('terminal_name')
            ->get();
        
        // Récupérer les employés avec leurs codes pour le filtre
        $employees = Employee::where('client_id', $client->id)
            ->whereNotNull('emp_code')
            ->where('emp_code', '!=', '')
            ->orderBy('emp_code')
            ->get()
            ->map(function($employee) {
                $fullName = $employee->first_name ?? '';
                if ($employee->last_name) {
                    $fullName .= ' ' . $employee->last_name;
                }
                $fullName = trim($fullName) ?: 'Code: ' . $employee->emp_code;
                
                return [
                    'emp_code' => $employee->emp_code,
                    'full_name' => $fullName
                ];
            });
        
        // Données d'aujourd'hui depuis la base
        $todayData = $this->getTodayDataFromDatabase($client);
        
        return view('attendance::index', compact('devices', 'employees', 'client', 'todayData'));
    }
    
    /**
     * Récupérer les données d'aujourd'hui depuis la base de données
     */
    private function getTodayDataFromDatabase($client)
    {
        try {
            $today = Carbon::today()->format('Y-m-d');
            
            Log::info("Récupération données pour aujourd'hui depuis DB: " . $today);
            
            // Récupérer toutes les présences d'aujourd'hui
            $attendances = DailyAttendance::where('client_id', $client->id)
                ->where('attendance_date', $today)
                ->with('employee')
                ->orderBy('attendance_date', 'desc')
                ->orderBy('emp_code')
                ->get();
            
            Log::info("Nombre de présences trouvées: " . $attendances->count());
            
            if ($attendances->isEmpty()) {
                return [
                    'success' => false,
                    'message' => 'Aucune présence enregistrée pour ' . Carbon::parse($today)->format('d/m/Y'),
                    'data' => []
                ];
            }
            
            // Formater les données pour l'affichage
            $formattedData = $this->formatAttendancesForDisplay($attendances);
            
            // Calculer les statistiques
            $stats = $this->calculateAttendanceStats($attendances);
            
            return [
                'success' => true,
                'message' => 'Données récupérées avec succès',
                'date' => Carbon::parse($today)->format('d/m/Y'),
                'total_attendances' => $attendances->count(),
                'matched_employees' => $stats['matched_employees'],
                'unmatched_employees' => $stats['unmatched_employees'],
                'unmatched_codes' => $stats['unmatched_codes'],
                'stats' => $stats,
                'data' => $formattedData
            ];
            
        } catch (\Exception $e) {
            Log::error('Erreur récupération données DB: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Erreur: ' . $e->getMessage(),
                'data' => []
            ];
        }
    }
    
    /**
     * Récupérer les données pour DataTables depuis la base de données
     */
    public function getData(Request $request)
    {
        try {
            $client = Client::where('user_id', auth()->user()->id)->first();
            
            if (!$client) {
                return response()->json(['error' => 'Client non trouvé'], 404);
            }
            
            // Valider les paramètres
            $request->validate([
                'start_date' => 'nullable|date',
                'end_date' => 'nullable|date|after_or_equal:start_date',
                'emp_code' => 'nullable|string',
                'terminal_sn' => 'nullable|string'
            ]);
            
            // Récupérer les paramètres
            $startDate = $request->input('start_date');
            $endDate = $request->input('end_date');
            $empCode = $request->input('emp_code');
            $terminalSn = $request->input('terminal_sn');
            
            // Si aucune date n'est fournie, utiliser aujourd'hui
            if (!$startDate && !$endDate) {
                $today = Carbon::today();
                $startDate = $today->format('Y-m-d');
                $endDate = $today->format('Y-m-d');
            } elseif ($startDate && !$endDate) {
                $endDate = $startDate;
            } elseif (!$startDate && $endDate) {
                $startDate = $endDate;
            }
            
            Log::info("Récupération données depuis DB pour: " . $startDate . " à " . $endDate . 
                     ", emp_code: " . ($empCode ?: 'all'));
            
            // Construire la requête
            $query = DailyAttendance::where('client_id', $client->id)
                ->whereBetween('attendance_date', [$startDate, $endDate])
                ->with('employee');
            
            // Appliquer les filtres
            if ($empCode && $empCode !== 'all') {
                $query->where('emp_code', $empCode);
            }
            
            // Filtrer par appareil si nécessaire (à partir des données brutes)
            if ($terminalSn && $terminalSn !== 'all') {
                $query->where('raw_data', 'LIKE', '%"' . $terminalSn . '"%');
            }
            
            // Exécuter la requête
            $attendances = $query->orderBy('attendance_date', 'desc')
                ->orderBy('emp_code')
                ->get();
            
            Log::info("Total présences récupérées depuis DB: " . $attendances->count());
            
            if ($attendances->isEmpty()) {
                return response()->json([
                    'draw' => $request->input('draw', 1),
                    'recordsTotal' => 0,
                    'recordsFiltered' => 0,
                    'data' => []
                ]);
            }
            
            // Convertir en tableau pour DataTables
            $data = $this->formatAttendancesForDataTables($attendances);
            
            // Pagination manuelle pour DataTables
            $totalRecords = count($data);
            $start = $request->input('start', 0);
            $length = $request->input('length', 50);
            $pageData = array_slice($data, $start, $length);
            
            return response()->json([
                'draw' => $request->input('draw', 1),
                'recordsTotal' => $totalRecords,
                'recordsFiltered' => $totalRecords,
                'data' => $pageData
            ]);
            
        } catch (\Exception $e) {
            Log::error('Erreur récupération données pointages depuis DB: ' . $e->getMessage());
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
    
    /**
     * Formater les présences pour l'affichage
     */
    private function formatAttendancesForDisplay($attendances)
    {
        return $attendances->map(function ($attendance) {
            // Décoder les données brutes
            $rawData = json_decode($attendance->raw_data, true) ?? [];
            
            // Extraire les horaires de pointage depuis raw_data
            $punchTimes = collect($rawData)
                ->pluck('punch_time')
                ->map(function ($time) {
                    try {
                        return Carbon::parse($time)->format('H:i:s');
                    } catch (\Exception $e) {
                        return $time;
                    }
                })
                ->filter()
                ->sort()
                ->values()
                ->toArray();
            
            // Extraire les appareils utilisés
            $devicesUsed = collect($rawData)
                ->pluck('terminal_alias')
                ->unique()
                ->filter()
                ->implode(', ');
            
            // Nom complet de l'employé
            $fullName = 'Non enregistré';
            if ($attendance->employee) {
                $fullName = $attendance->employee->first_name ?? '';
                if ($attendance->employee->last_name) {
                    $fullName .= ' ' . $attendance->employee->last_name;
                }
                $fullName = trim($fullName) ?: 'Employé ' . $attendance->emp_code;
            }
            
            // Formater le check-in et check-out
            $checkIn = $attendance->check_in ? Carbon::parse($attendance->check_in)->format('H:i:s') : null;
            $checkOut = $attendance->check_out ? Carbon::parse($attendance->check_out)->format('H:i:s') : null;
            
            return [
                'date' => $attendance->attendance_date,
                'date_formatted' => Carbon::parse($attendance->attendance_date)->format('d/m/Y'),
                'emp_code' => $attendance->emp_code,
                'full_name' => $fullName,
                'all_punches' => implode(', ', $punchTimes),
                'punch_times' => $punchTimes,
                'first_punch' => !empty($punchTimes) ? $punchTimes[0] : null,
                'last_punch' => !empty($punchTimes) ? end($punchTimes) : null,
                'check_in' => $checkIn,
                'check_out' => $checkOut,
                'total_punches' => count($punchTimes),
                'total_work_hours' => $attendance->work_hours,
                'effective_hours' => $attendance->effective_hours ?? $attendance->work_hours,
                'break_hours' => $attendance->break_hours ?? 1,
                'overtime_hours' => $attendance->overtime_hours ?? 0,
                'devices_used' => $devicesUsed ?: 'Non disponible',
                'status' => $attendance->status,
                'status_label' => $this->getStatusLabel($attendance->status),
                'status_class' => $this->getStatusClass($attendance->status),
                'is_late' => (bool) $attendance->is_late,
                'late_minutes' => $attendance->late_minutes ?? 0,
                'is_early_leave' => (bool) $attendance->is_early_leave,
                'early_minutes' => $attendance->early_minutes ?? 0,
                'is_overtime' => (bool) $attendance->is_overtime,
                'is_short_work' => (bool) $attendance->is_short_work,
                'short_hours' => $attendance->short_hours ?? 0,
                'notes' => $attendance->notes,
                'employee_found' => $attendance->employee ? 'oui' : 'non',
                'has_multiple_punches' => count($punchTimes) > 2,
                'raw_data_count' => count($rawData),
                'last_sync_at' => $attendance->last_sync_at ? Carbon::parse($attendance->last_sync_at)->format('H:i:s') : null,
                'updated_at' => $attendance->updated_at ? Carbon::parse($attendance->updated_at)->format('d/m/Y H:i:s') : null
            ];
        })->toArray();
    }
    
    /**
     * Formater les présences pour DataTables
     */
    private function formatAttendancesForDataTables($attendances)
    {
        return $attendances->map(function ($attendance) {
            // Décoder les données brutes
            $rawData = json_decode($attendance->raw_data, true) ?? [];
            
            // Extraire les horaires de pointage
            $punchTimes = collect($rawData)
                ->pluck('punch_time')
                ->map(function ($time) {
                    try {
                        return Carbon::parse($time)->format('H:i:s');
                    } catch (\Exception $e) {
                        return $time;
                    }
                })
                ->filter()
                ->sort()
                ->values()
                ->toArray();
            
            // Extraire les appareils utilisés
            $devicesUsed = collect($rawData)
                ->pluck('terminal_alias')
                ->unique()
                ->filter()
                ->implode(', ');
            
            // Nom complet de l'employé
            $fullName = 'Non enregistré';
            if ($attendance->employee) {
                $fullName = $attendance->employee->first_name ?? '';
                if ($attendance->employee->last_name) {
                    $fullName .= ' ' . $attendance->employee->last_name;
                }
                $fullName = trim($fullName) ?: 'Employé ' . $attendance->emp_code;
            }
            
            // Formater pour DataTables
            return [
                'DT_RowId' => 'row_' . $attendance->id,
                'date' => $attendance->attendance_date,
                'date_formatted' => Carbon::parse($attendance->attendance_date)->format('d/m/Y'),
                'employee' => [
                    'first_name' => $attendance->employee->first_name ?? '',
                    'last_name' => $attendance->employee->last_name ?? '',
                    'emp_code' => $attendance->emp_code,
                    'full_name' => $fullName
                ],
                'emp_code' => $attendance->emp_code,
                'full_name' => $fullName,
                'all_punches' => implode(', ', $punchTimes),
                'punch_list' => $punchTimes,
                'first_punch' => !empty($punchTimes) ? $punchTimes[0] : null,
                'last_punch' => !empty($punchTimes) ? end($punchTimes) : null,
                'check_in' => $attendance->check_in ? Carbon::parse($attendance->check_in)->format('H:i:s') : null,
                'check_out' => $attendance->check_out ? Carbon::parse($attendance->check_out)->format('H:i:s') : null,
                'total_punches' => count($punchTimes),
                'total_work_hours' => $attendance->work_hours,
                'effective_hours' => $attendance->effective_hours ?? $attendance->work_hours,
                'overtime_hours' => $attendance->overtime_hours ?? 0,
                'devices_used' => $devicesUsed ?: 'Non disponible',
                'status' => $attendance->status,
                'status_label' => $this->getStatusLabel($attendance->status),
                'is_late' => (bool) $attendance->is_late,
                'late_minutes' => $attendance->late_minutes ?? 0,
                'is_early_leave' => (bool) $attendance->is_early_leave,
                'early_minutes' => $attendance->early_minutes ?? 0,
                'is_overtime' => (bool) $attendance->is_overtime,
                'is_short_work' => (bool) $attendance->is_short_work,
                'notes' => $attendance->notes,
                'employee_found' => $attendance->employee ? 'yes' : 'no',
                'has_multiple_punches' => count($punchTimes) > 2,
                'raw_data_count' => count($rawData),
                'observation' => $this->generateObservation($attendance),
                'actions' => $this->getActionButtons($attendance)
            ];
        })->toArray();
    }
    
    /**
     * Calculer les statistiques des présences
     */
    private function calculateAttendanceStats($attendances)
    {
        $total = $attendances->count();
        $present = $attendances->whereIn('status', ['PRESENT', 'LATE', 'OVERTIME', 'SHORT_WORK'])->count();
        $absent = $attendances->where('status', 'ABSENT')->count();
        $late = $attendances->where('status', 'LATE')->count();
        $halfDay = $attendances->where('status', 'HALF_DAY')->count();
        $leave = $attendances->where('status', 'LEAVE')->count();
        $overtime = $attendances->where('is_overtime', true)->count();
        
        // Employés avec correspondance
        $matchedEmployees = $attendances->whereNotNull('employee_id')->count();
        $unmatchedEmployees = $attendances->whereNull('employee_id')->count();
        
        // Codes non trouvés
        $unmatchedCodes = $attendances->whereNull('employee_id')
            ->pluck('emp_code')
            ->unique()
            ->values()
            ->toArray();
        
        // Moyennes
        $avgWorkHours = round($attendances->whereNotNull('work_hours')->avg('work_hours') ?? 0, 2);
        $avgOvertime = round($attendances->whereNotNull('overtime_hours')->avg('overtime_hours') ?? 0, 2);
        
        return [
            'total_days' => $total,
            'present_days' => $present,
            'absent_days' => $absent,
            'late_days' => $late,
            'half_days' => $halfDay,
            'leave_days' => $leave,
            'overtime_days' => $overtime,
            'matched_employees' => $matchedEmployees,
            'unmatched_employees' => $unmatchedEmployees,
            'unmatched_codes' => $unmatchedCodes,
            'avg_work_hours' => $avgWorkHours,
            'avg_overtime_hours' => $avgOvertime,
            'total_overtime_hours' => round($attendances->sum('overtime_hours') ?? 0, 2)
        ];
    }
    
    /**
     * Obtenir le label du statut
     */
    private function getStatusLabel($status)
    {
        $labels = [
            'PRESENT' => 'Présent',
            'ABSENT' => 'Absent',
            'LATE' => 'Retard',
            'EARLY_LEAVE' => 'Départ anticipé',
            'HALF_DAY' => 'Demi-journée',
            'OVERTIME' => 'Heures supplémentaires',
            'SHORT_WORK' => 'Travail court',
            'LEAVE' => 'Congé',
            'IRREGULAR' => 'Irregular',
            'MULTIPLE_PUNCHES' => 'Pointages multiples'
        ];
        
        return $labels[$status] ?? $status;
    }
    
    /**
     * Obtenir la classe CSS du statut
     */
    private function getStatusClass($status)
    {
        $classes = [
            'PRESENT' => 'success',
            'ABSENT' => 'danger',
            'LATE' => 'warning',
            'EARLY_LEAVE' => 'warning',
            'HALF_DAY' => 'info',
            'OVERTIME' => 'primary',
            'SHORT_WORK' => 'warning',
            'LEAVE' => 'secondary',
            'IRREGULAR' => 'warning',
            'MULTIPLE_PUNCHES' => 'info'
        ];
        
        return $classes[$status] ?? 'secondary';
    }
    
    /**
     * Générer une observation basée sur les données
     */
    private function generateObservation($attendance)
    {
        $observations = [];
        
        if ($attendance->is_late && $attendance->late_minutes > 0) {
            $observations[] = "Retard de {$attendance->late_minutes} min";
        }
        
        if ($attendance->is_early_leave && $attendance->early_minutes > 0) {
            $observations[] = "Départ anticipé de {$attendance->early_minutes} min";
        }
        
        if ($attendance->is_overtime && $attendance->overtime_hours > 0) {
            $observations[] = "Heures supp: {$attendance->overtime_hours}h";
        }
        
        if ($attendance->is_short_work && $attendance->short_hours > 0) {
            $observations[] = "Manque: {$attendance->short_hours}h";
        }
        
        if (!empty($observations)) {
            return implode(' | ', $observations);
        }
        
        // Compter les pointages depuis raw_data
        $rawData = json_decode($attendance->raw_data, true) ?? [];
        $punchCount = count($rawData);
        
        if ($punchCount > 0) {
            return "{$punchCount} pointage" . ($punchCount > 1 ? 's' : '');
        }
        
        return $attendance->notes ?: '';
    }
    
    /**
     * Obtenir les boutons d'action
     */
    private function getActionButtons($attendance)
    {
        $buttons = [];
        
        // Bouton pour voir les détails
        $buttons[] = '<button class="btn btn-sm btn-info view-details" 
                      data-id="' . $attendance->id . '" 
                      data-emp-code="' . $attendance->emp_code . '"
                      data-date="' . $attendance->attendance_date . '"
                      title="Voir détails">
                        <i class="fas fa-eye"></i>
                    </button>';
        
        // Bouton pour resynchroniser
        $buttons[] = '<button class="btn btn-sm btn-warning resync-attendance" 
                      data-id="' . $attendance->id . '"
                      data-emp-code="' . $attendance->emp_code . '"
                      data-date="' . $attendance->attendance_date . '"
                      title="Resynchroniser">
                        <i class="fas fa-sync-alt"></i>
                    </button>';
        
        return implode(' ', $buttons);
    }
    
    /**
     * Récupérer le statut de synchronisation
     */
    public function syncStatus(Request $request)
    {
        try {
            $client = Client::where('user_id', auth()->user()->id)->first();
            
            if (!$client) {
                return response()->json([
                    'client_name' => 'Non associé',
                    'last_sync' => 'N/A',
                    'current_date' => date('d/m/Y')
                ]);
            }
            
            // Dernière synchronisation depuis les données
            $lastSync = DailyAttendance::where('client_id', $client->id)
                ->whereNotNull('last_sync_at')
                ->orderBy('last_sync_at', 'desc')
                ->first();
            
            // Données d'aujourd'hui
            $todayData = $this->getTodayDataFromDatabase($client);
            
            return response()->json([
                'client_name' => $client->nraison_sociale,
                'last_sync' => $lastSync ? Carbon::parse($lastSync->last_sync_at)->format('d/m/Y H:i:s') : 'Jamais',
                'current_date' => date('d/m/Y'),
                'today_count' => $todayData['success'] ? $todayData['total_attendances'] : 0,
                'today_message' => $todayData['message']
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'client_name' => 'Erreur',
                'last_sync' => 'N/A',
                'current_date' => date('d/m/Y')
            ]);
        }
    }
    
    /**
     * Resynchroniser une présence spécifique
     */
    public function resyncAttendance(Request $request)
    {
        try {
            $client = Client::where('user_id', auth()->user()->id)->first();
            
            if (!$client) {
                return response()->json([
                    'success' => false,
                    'message' => 'Client non trouvé.'
                ], 404);
            }
            
            $attendanceId = $request->input('attendance_id');
            $empCode = $request->input('emp_code');
            $date = $request->input('date');
            
            // Forcer la mise à jour pour cette date
            if ($date) {
                $carbonDate = Carbon::parse($date);
                
                // Synchroniser les transactions depuis l'API
                $accessConfig = DB::table('access_configs')->where('client_id', $client->id)->first();
                
                if (!$accessConfig || !$accessConfig->general_token) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Token d\'accès non configuré.'
                    ], 400);
                }
                
                // Synchroniser pour la date spécifique
                $this->attendanceService->syncForDate($carbonDate);
                
                Log::info("Resynchronisation manuelle pour {$empCode} le {$date}");
                
                // Récupérer la présence mise à jour
                $attendance = DailyAttendance::where('client_id', $client->id)
                    ->where('emp_code', $empCode)
                    ->where('attendance_date', $date)
                    ->first();
                
                if ($attendance) {
                    return response()->json([
                        'success' => true,
                        'message' => 'Présence resynchronisée avec succès.',
                        'attendance' => [
                            'id' => $attendance->id,
                            'date' => $attendance->attendance_date,
                            'status' => $attendance->status,
                            'check_in' => $attendance->check_in ? Carbon::parse($attendance->check_in)->format('H:i:s') : null,
                            'check_out' => $attendance->check_out ? Carbon::parse($attendance->check_out)->format('H:i:s') : null,
                            'work_hours' => $attendance->work_hours,
                            'last_sync_at' => $attendance->last_sync_at ? Carbon::parse($attendance->last_sync_at)->format('H:i:s') : null
                        ]
                    ]);
                }
            }
            
            return response()->json([
                'success' => false,
                'message' => 'Impossible de resynchroniser.'
            ], 400);
            
        } catch (\Exception $e) {
            Log::error('Erreur resynchronisation: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Erreur: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Afficher les détails d'une présence
     */
    public function showDetails(Request $request)
    {
        try {
            $attendanceId = $request->input('attendance_id');
            
            $attendance = DailyAttendance::with(['client', 'employee'])
                ->find($attendanceId);
            
            if (!$attendance) {
                return response()->json([
                    'success' => false,
                    'message' => 'Présence non trouvée.'
                ], 404);
            }
            
            // Décoder les données brutes
            $rawData = json_decode($attendance->raw_data, true) ?? [];
            
            // Formater les données brutes
            $formattedRawData = collect($rawData)->map(function ($transaction) {
                return [
                    'transaction_id' => $transaction['id'] ?? $transaction['transaction_id'] ?? null,
                    'punch_time' => isset($transaction['punch_time']) ? 
                        Carbon::parse($transaction['punch_time'])->format('d/m/Y H:i:s') : null,
                    'terminal_alias' => $transaction['terminal_alias'] ?? null,
                    'area_alias' => $transaction['area_alias'] ?? null,
                    'verify_type' => $transaction['verify_type'] ?? null,
                    'punch_state' => $transaction['punch_state'] ?? null
                ];
            });
            
            // Calculer les statistiques détaillées
            $punchTimes = collect($rawData)
                ->pluck('punch_time')
                ->map(function ($time) {
                    try {
                        return Carbon::parse($time);
                    } catch (\Exception $e) {
                        return null;
                    }
                })
                ->filter()
                ->sort();
            
            $timeSegments = [];
            if ($punchTimes->count() >= 2) {
                for ($i = 0; $i < $punchTimes->count() - 1; $i++) {
                    $segmentStart = $punchTimes[$i];
                    $segmentEnd = $punchTimes[$i + 1];
                    
                    if ($segmentStart && $segmentEnd) {
                        $durationMinutes = $segmentStart->diffInMinutes($segmentEnd);
                        $timeSegments[] = [
                            'start' => $segmentStart->format('H:i:s'),
                            'end' => $segmentEnd->format('H:i:s'),
                            'duration_minutes' => $durationMinutes,
                            'duration_hours' => round($durationMinutes / 60, 2)
                        ];
                    }
                }
            }
            
            // Informations employé
            $employeeInfo = null;
            if ($attendance->employee) {
                $employeeInfo = [
                    'full_name' => ($attendance->employee->first_name ?? '') . ' ' . ($attendance->employee->last_name ?? ''),
                    'employee_id' => $attendance->employee->employee_id,
                    'email' => $attendance->employee->email,
                    'phone' => $attendance->employee->phone,
                    'department' => $attendance->employee->department
                ];
            }
            
            return response()->json([
                'success' => true,
                'attendance' => [
                    'id' => $attendance->id,
                    'date' => Carbon::parse($attendance->attendance_date)->format('d/m/Y'),
                    'emp_code' => $attendance->emp_code,
                    'status' => $attendance->status,
                    'status_label' => $this->getStatusLabel($attendance->status),
                    'check_in' => $attendance->check_in ? Carbon::parse($attendance->check_in)->format('H:i:s') : null,
                    'check_out' => $attendance->check_out ? Carbon::parse($attendance->check_out)->format('H:i:s') : null,
                    'work_hours' => $attendance->work_hours,
                    'effective_hours' => $attendance->effective_hours,
                    'break_hours' => $attendance->break_hours,
                    'overtime_hours' => $attendance->overtime_hours,
                    'is_late' => (bool) $attendance->is_late,
                    'late_minutes' => $attendance->late_minutes,
                    'is_early_leave' => (bool) $attendance->is_early_leave,
                    'early_minutes' => $attendance->early_minutes,
                    'is_overtime' => (bool) $attendance->is_overtime,
                    'is_short_work' => (bool) $attendance->is_short_work,
                    'short_hours' => $attendance->short_hours,
                    'notes' => $attendance->notes,
                    'raw_data_count' => count($rawData),
                    'last_sync_at' => $attendance->last_sync_at ? Carbon::parse($attendance->last_sync_at)->format('d/m/Y H:i:s') : null,
                    'updated_at' => $attendance->updated_at ? Carbon::parse($attendance->updated_at)->format('d/m/Y H:i:s') : null
                ],
                'employee' => $employeeInfo,
                'raw_data' => $formattedRawData,
                'time_segments' => $timeSegments,
                'statistics' => [
                    'total_punches' => $punchTimes->count(),
                    'time_segments_count' => count($timeSegments),
                    'total_segment_hours' => round(collect($timeSegments)->sum('duration_minutes') / 60, 2)
                ]
            ]);
            
        } catch (\Exception $e) {
            Log::error('Erreur affichage détails: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Erreur: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Exporter les présences en PDF
     */
    public function exportPDF(Request $request)
    {
        try {
            $client = Client::where('user_id', auth()->user()->id)->first();
            
            if (!$client) {
                return response()->json([
                    'success' => false,
                    'message' => 'Client non trouvé.'
                ], 404);
            }
            
            // Récupérer les paramètres de filtre
            $startDate = $request->input('start_date');
            $endDate = $request->input('end_date');
            $empCode = $request->input('emp_code');
            
            // Si aucune date n'est fournie, utiliser aujourd'hui
            if (!$startDate && !$endDate) {
                $startDate = Carbon::today()->format('Y-m-d');
                $endDate = Carbon::today()->format('Y-m-d');
            } elseif ($startDate && !$endDate) {
                $endDate = $startDate;
            } elseif (!$startDate && $endDate) {
                $startDate = $endDate;
            }
            
            Log::info("Export PDF depuis DB pour: " . $startDate . " à " . $endDate);
            
            // Construire la requête
            $query = DailyAttendance::where('client_id', $client->id)
                ->whereBetween('attendance_date', [$startDate, $endDate])
                ->with('employee')
                ->orderBy('attendance_date', 'desc')
                ->orderBy('emp_code');
            
            if ($empCode && $empCode !== 'all') {
                $query->where('emp_code', $empCode);
            }
            
            $attendances = $query->get();
            
            Log::info("Export PDF - Total présences: " . $attendances->count());
            
            if ($attendances->isEmpty()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Aucune donnée à exporter pour cette période.'
                ], 400);
            }
            
            // Formater les données pour l'export
            $exportData = $this->formatAttendancesForExport($attendances);
            
            // Calculer les statistiques
            $statistics = $this->calculateAttendanceStats($attendances);
            
            // Préparer les filtres
            $filters = $this->prepareFiltersForDisplay($request, $client);
            
            // Générer le PDF
            $pdf = PDF::loadView('attendance::exports.pdf', [
                'attendances' => $exportData,
                'client' => $client,
                'filters' => $filters,
                'statistics' => $statistics,
                'export_date' => now()->format('d/m/Y H:i'),
                'start_date' => Carbon::parse($startDate)->format('d/m/Y'),
                'end_date' => Carbon::parse($endDate)->format('d/m/Y'),
            ]);
            
            // Nom du fichier
            $filename = 'presences_' . $client->name . '_' . 
                       Carbon::parse($startDate)->format('Ymd') . '_' . 
                       Carbon::parse($endDate)->format('Ymd') . '.pdf';
            
            // Sauvegarder le PDF
            $pdfPath = storage_path('app/public/pdfs/' . $filename);
            
            if (!file_exists(dirname($pdfPath))) {
                mkdir(dirname($pdfPath), 0755, true);
            }
            
            $pdf->save($pdfPath);
            
            // URL pour télécharger
            $pdfUrl = asset('storage/pdfs/' . $filename);
            
            return response()->json([
                'success' => true,
                'message' => 'PDF généré avec succès',
                'pdf_url' => $pdfUrl,
                'filename' => $filename,
                'statistics' => [
                    'total_attendances' => count($exportData),
                    'total_employees' => collect($exportData)->pluck('emp_code')->unique()->count(),
                    'period' => Carbon::parse($startDate)->format('d/m/Y') . ' - ' . Carbon::parse($endDate)->format('d/m/Y')
                ]
            ]);
            
        } catch (\Exception $e) {
            Log::error('Erreur export PDF: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de l\'export: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Formater les présences pour l'export
     */
    private function formatAttendancesForExport($attendances)
    {
        return $attendances->map(function ($attendance) {
            // Décoder raw_data
            $rawData = json_decode($attendance->raw_data, true) ?? [];
            
            // Extraire les pointages
            $punchTimes = collect($rawData)
                ->pluck('punch_time')
                ->map(function ($time) {
                    try {
                        return Carbon::parse($time)->format('H:i:s');
                    } catch (\Exception $e) {
                        return $time;
                    }
                })
                ->filter()
                ->sort()
                ->values()
                ->toArray();
            
            // Nom complet
            $fullName = 'Non enregistré';
            if ($attendance->employee) {
                $fullName = $attendance->employee->first_name ?? '';
                if ($attendance->employee->last_name) {
                    $fullName .= ' ' . $attendance->employee->last_name;
                }
                $fullName = trim($fullName) ?: 'Employé ' . $attendance->emp_code;
            }
            
            return [
                'date' => Carbon::parse($attendance->attendance_date)->format('d/m/Y'),
                'emp_code' => $attendance->emp_code,
                'full_name' => $fullName,
                'check_in' => $attendance->check_in ? Carbon::parse($attendance->check_in)->format('H:i:s') : 'N/A',
                'check_out' => $attendance->check_out ? Carbon::parse($attendance->check_out)->format('H:i:s') : 'N/A',
                'work_hours' => $attendance->work_hours ?? 0,
                'overtime_hours' => $attendance->overtime_hours ?? 0,
                'status' => $this->getStatusLabel($attendance->status),
                'punch_times' => implode(', ', $punchTimes),
                'total_punches' => count($punchTimes),
                'notes' => $attendance->notes
            ];
        })->toArray();
    }
    
    /**
     * Préparer les filtres pour l'affichage
     */
    private function prepareFiltersForDisplay($request, $client)
    {
        $filters = [];
        
        if ($request->has('start_date') && $request->start_date) {
            $filters['date_début'] = Carbon::parse($request->start_date)->format('d/m/Y');
        }
        
        if ($request->has('end_date') && $request->end_date) {
            $filters['date_fin'] = Carbon::parse($request->end_date)->format('d/m/Y');
        }
        
        if ($request->has('emp_code') && $request->emp_code && $request->emp_code !== 'all') {
            $employee = Employee::where('client_id', $client->id)
                ->where('emp_code', $request->emp_code)
                ->first();
                
            if ($employee) {
                $fullName = $employee->first_name ?? '';
                if ($employee->last_name) {
                    $fullName .= ' ' . $employee->last_name;
                }
                $filters['employé'] = $fullName . ' (' . $request->emp_code . ')';
            } else {
                $filters['code_employé'] = $request->emp_code;
            }
        }
        
        return $filters;
    }
    
    /**
     * Récupérer un employé par son code
     */
    public function getEmployeeByCode(Request $request)
    {
        $client = Client::where('user_id', auth()->user()->id)->first();
        
        if (!$client || !$request->has('emp_code')) {
            return response()->json(null);
        }
        
        $employee = Employee::where('client_id', $client->id)
            ->where('emp_code', $request->emp_code)
            ->first();
            
        if ($employee) {
            $fullName = $employee->first_name ?? '';
            if ($employee->last_name) {
                $fullName .= ' ' . $employee->last_name;
            }
            $fullName = trim($fullName) ?: 'Employé ' . $employee->emp_code;
            
            return response()->json([
                'id' => $employee->id,
                'employee_id' => $employee->employee_id,
                'emp_code' => $employee->emp_code,
                'first_name' => $employee->first_name,
                'last_name' => $employee->last_name,
                'full_name' => $fullName
            ]);
        }
        
        return response()->json(null);
    }
}