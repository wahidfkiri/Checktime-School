<?php
use Illuminate\Support\Facades\Route;
use Vendor\Attendance\Http\Controllers\DailyAttendanceController;



// Gestion des présences
Route::prefix('admin/daily-attendance')->group(function () {
    Route::get('/', [DailyAttendanceController::class, 'index'])->name('admin.daily-attendance.index');
    Route::get('/data', [DailyAttendanceController::class, 'getData'])->name('admin.daily-attendance.data');
    Route::post('/sync', [DailyAttendanceController::class, 'sync'])->name('admin.daily-attendance.sync');
    Route::get('/sync-status', [DailyAttendanceController::class, 'syncStatus'])->name('admin.daily-attendance.sync-status');
    Route::get('/test-api', [DailyAttendanceController::class, 'testSync'])->name('admin.daily-attendance.test-api');
    Route::get('/debug-codes', [DailyAttendanceController::class, 'debugEmpCodes'])->name('admin.daily-attendance.debug-codes');
     Route::get('/get-employee-by-code', [DailyAttendanceController::class, 'getEmployeeByCode'])->name('admin.daily-attendance.get-employee-by-code');
     Route::post('/export-pdf', [DailyAttendanceController::class, 'exportPDF'])->name('admin.daily-attendance.export-pdf');
     Route::get('/api-diagnostic', [DailyAttendanceController::class, 'apiDiagnostic'])->name('admin.daily-attendance.api-diagnostic');
});